class Tablero {
    var tablero = Array(7){Array<Int>(4){0}}
    var jugada = tablero.size
    var pista = Array(7){Array<Int>(4){0}}


    fun jugar (a:Array<Int>, p:Array<Int>){
        jugada--
        for (i in 0..<a.size){
            tablero[jugada][i]=a[i]
        }
        for (i in 0..<p.size){
            pista[jugada][i]=p[i]
        }
    }

    fun imprimirTablero(){
        for (i in 0..<tablero.size){
            for (j in 0..<tablero[i].size){
                print("["+Color.values()[tablero[i][j]].emoji+"]")
            }
            print("\t")
            for(j in 0..<pista[i].size){
                print("["+Color.values()[pista[i][j]].emoji+"]")
            }
            println()
        }
    }

    constructor(){}

}