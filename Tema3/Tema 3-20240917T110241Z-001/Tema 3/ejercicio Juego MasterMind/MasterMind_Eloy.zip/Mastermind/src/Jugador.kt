class Jugador {
    var nombre = ""
    var eleccion = Array<Int>(4){0}
    var tablero = Tablero()
    var objetivo = Array(4){random()}

    fun movimiento(){

        println("Selecciona 4 colores en orden")
        println("1.-Verde")
        println("2.-Azul")
        println("3.-Rojo")
        println("4.-Amarillo")
        println("5.-Naranja")

        for (i in 0..<eleccion.size){
            eleccion[i] = readln().toInt()
        }

        tablero.jugar(eleccion,corregir(eleccion))


    }

    fun corregir(a:Array<Int>):Array<Int>{
        var bien = 0
        var ok = 0
        var cont = 0
        val comparar = Array(4){0}
        val pista = Array(4){0}

        for(i in 0..<a.size) {
            if (a[i] == objetivo[i] && comparar[i] == 0) {
                bien++
                comparar[i] = 1
            }
        }

        for(i in 0..<a.size) {
            for (j in 0..<objetivo.size) {
                if (a[i] == objetivo[j] && cont == 0 && comparar[j] == 0) {
                    ok++
                    cont++
                    comparar[j] = 1
                }
            }
            cont=0
        }

        if (bien>0){
            for (i in 0..<bien){
                pista[i] = 7
            }
        }
        if (ok>0 && bien>=0) {
            for (i in bien..<bien + ok){
                pista[i] = 6
            }
        }

        return pista
    }

    fun ganador():Boolean{
        var devolver = false
        if ((eleccion[1]==objetivo[1]) && (eleccion[2]==objetivo[2]) && (eleccion[3]==objetivo[3]) && (eleccion[0]==objetivo[0])){
            devolver=true
        }
        return devolver
    }

    fun random():Int{
        return (1..5).random()
    }

    constructor(nombre:String){
        this.nombre = nombre
    }

    constructor()
}
