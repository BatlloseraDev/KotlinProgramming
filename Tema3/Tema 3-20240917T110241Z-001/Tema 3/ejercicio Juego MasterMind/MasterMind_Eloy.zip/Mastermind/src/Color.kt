enum class Color (var emoji: String){
    OOO("\uD83D\uDD18"),
    VER("\uD83D\uDFE2"),
    AZU("\uD83D\uDD35"),
    ROJ("\uD83D\uDD34"),
    AMA("\uD83D\uDFE1"),
    NAR("\uD83D\uDFE0"),
    BLA("⚪"),
    NEG("⚫")
}