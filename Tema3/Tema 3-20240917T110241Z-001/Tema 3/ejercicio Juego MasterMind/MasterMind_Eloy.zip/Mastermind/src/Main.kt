fun main() {
    var j = Jugador()

    do{
        j.tablero.imprimirTablero()
        j.movimiento()
    }while (!j.ganador() && j.tablero.jugada>0)

    println("\n")
    j.tablero.imprimirTablero()

    if (j.ganador()){
        println("Ganaste")
    }else{
        println("Perdiste")
        print("Se buscaba la siguiente combinación de colores : ")

        for (i in j.objetivo){
            print("["+Color.values()[i].emoji+"]")
        }

    }
}