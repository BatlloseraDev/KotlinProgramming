enum class Colores(var valor:Int) {
    VERDE(1),
    NARANJA(2),
    AMARILLO(3),
    ROJO(4),
    AZUL(5);
}