fun main(args: Array<String>) {
    var t = Tablero(10)
    var pc = Jugador()
    var jugador = Jugador()

    t.imprimirTablero()
    println("*****Instrucciones del juego*****")
    println("Adivina la combinación y orden de colores")
    println("Si un color es correcto, pero no su posicion se indicara con *BLANCO* y si su color y posicion es correcto se indicara con *GRIS* y si no es correcto con *NEGRO*")

    //Se pone fuera del bucle para que no genere en cada ronda una combinacion aleatoria
    pc.crearCombinacionAleatoria()
    //este bucle es para las rondas que va a tener el juego, hasta que adivene la combinacion o se acabe el tablero "oportunidades de adivinar"

    do {
        var eleccion = jugador.adivinarPosicion()
        t.rellenarTableroIntentos(eleccion)
        t.imprimirTablero()
        pc.rellenarPistas(t)
        t.imprimirPistas()

    }while (!t.tableroLleno() && !t.esGanador())

    if (t.esGanador()){
        println("> Ganaste!!! :)")
    }else{
        println("> Perdiste :( ")
    }

}