enum class Pistas(var valor:Int) {
    BLANCO(1),
    NEGRO(2),
    GRIS(3);
}