class Jugador {

    var combinacion: Array<Int> = Array(4){0}

    fun crearCombinacionAleatoria(){
        var contador = 0

        while (contador <= combinacion.lastIndex){
            var color = Colores.entries.toTypedArray().random()
            combinacion[contador] = color.valor
            contador++
        }
    }

    //Funcion para que el usuario diga la combinacion que cree, se guarda en un array y se recorre para que saber las posiciones de cada color
    fun adivinarPosicion():Array<Int>{
        var elecciones:Array<Int> = Array(4){0}
        println("***Elige los colores***")
        println("1.Azul 2.Naranja 3.Amarillo 4.Rojo 5.Verde")
        var i = 0
        while (i <= elecciones.lastIndex){
            print("Posicion ${i+1}: ")
            elecciones[i] = readln().toInt()
            i++
        }
        return elecciones
    }

    //Comprobar lo que ha metido el jugador y rellenar pistas
    fun rellenarPistas(tablero: Tablero){
        //Obterner la fila que hay que comprobar en base a la ronda
        var fila = tablero.ronda
        //Recorrer las columnas de la fila que se ha sacado
        for (i in 0..<tablero.numeroColumnas){

            if (tablero.tablero[fila][i] == combinacion[i]){
                //Si es acertado el color y la posicion, es BLANCO (1)
                tablero.pistas[fila][i] = Pistas.BLANCO.valor
            }else if (comprobarCoincidencia(tablero.pistas[fila][i],combinacion)){
                //Si el color es acertado pero no la posicion es GRIS (2)
                tablero.pistas[fila][i] = Pistas.GRIS.valor
            }else{
                //Si no se acierta ni el color ni la posicion es NEGRO(3)
                tablero.pistas[fila][i] = Pistas.NEGRO.valor
            }
        }
        tablero.aumentarRonda()
    }

    fun comprobarCoincidencia(numero:Int,array:Array<Int>):Boolean{
        var coincidencia = false
        for (i in 0..<array.size){
            if (array[i] == numero){
                coincidencia = true
            }
        }
        return coincidencia
    }

}