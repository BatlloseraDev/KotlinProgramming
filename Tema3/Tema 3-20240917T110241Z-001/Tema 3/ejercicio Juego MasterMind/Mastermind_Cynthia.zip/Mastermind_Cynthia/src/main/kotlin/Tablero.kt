class Tablero {
    var numeroFilas = 0
    var numeroColumnas = 4
    var tablero:Array<Array<Int>>
    var ronda = 0
    var pistas:Array<Array<Int>>

    //Construccion del tablero
    constructor(f:Int){
        this.numeroFilas = f
        tablero = Array(numeroFilas){ Array(numeroColumnas) {0} }
        pistas = Array (numeroFilas){Array(numeroColumnas){0} }

    }
    //Se pinta al reves el tablero
    fun imprimirTablero(){
        var i = numeroFilas -1
        var j= 0
        while (i>=0 && j<numeroColumnas){
            print("[${tablero[i][j]}]")
            j++
            if (j == numeroColumnas){
                i--
                j=0
                println()
            }
        }
    }

    fun imprimirPistas(){
        var i = numeroFilas -1
        var j= 0
        println("*****Pistas*****")
        while (i>=0 && j<numeroColumnas){
            print("[${pistas[i][j]}]")
            j++
            if (j == numeroColumnas){
                i--
                j=0
                println()
            }
        }
    }



    // Esta funcion comprueba que en la ultima fila en la primera posicion este vacia y si no, el tablero esta lleno
    fun tableroLleno():Boolean {
        var ultimaFila = tablero.last() //devuelve el ultimo elemento de la matriz(la ultima fila)
        var lleno = true
        if (ultimaFila[0] == 0){
            lleno = false
        }
        return lleno
    }

    fun rellenarTableroIntentos(jugada:Array<Int>){

        tablero[ronda] = jugada
    }

    fun aumentarRonda(){
        ronda++
    }

    fun esGanador():Boolean{
        var ganador = true
        var i = 0
        while (ganador && i < pistas[ronda-1].size){
            if (pistas[ronda-1][i] != Pistas.BLANCO.valor){
                ganador = false
            }
            i++
        }
        return ganador
    }



}