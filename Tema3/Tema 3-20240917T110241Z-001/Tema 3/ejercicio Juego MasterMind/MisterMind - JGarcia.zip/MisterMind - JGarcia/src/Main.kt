fun main() {
    val tablero = Tablero(4,7)
    val jugador1 = Jugador("Jose")
    val jugador2 = Jugador("CPU", true)

    var blanco = "\u26AA"
    var negro = "\u26AB"

    println("MasterMind")
    println(jugador1.Nombre + " vs " + jugador2.Nombre)
    println("Dimensiones del tablero X:" + tablero.x + " - Y:" + tablero.y)
    println("########################")

    if (jugador1.isBot) {
        jugador1.jugar(tablero)
        jugador2.jugar(tablero)
    } else{
        jugador2.jugar(tablero)
        jugador1.jugar(tablero)
    }
}