import kotlin.system.exitProcess

class Tablero(xTablero: Int, yTablero: Int) {
    var x = xTablero
    var y = yTablero

    var TableroJuego = Array(this.y) { Array(this.x) { "_" } }
    var TableroAciertos = Array(this.y) { Array(this.x) { "_" } }

    fun mostrarTablero() {
        var n = this.TableroJuego.size
        println("  * Tablero *  * Aciertos *")
        for (i in 0..<this.TableroJuego.size) {
            print(n)
            for (j in 0..<this.TableroJuego[i].size) {
                print("[" + this.TableroJuego[i][j] + "]")
            }
            print("||")
            for (j in 0..<this.TableroAciertos[i].size) {
                print("[" + this.TableroAciertos[i][j] + "]")
            }
            println()
            n--
        }
    }

    fun establecerMovimiento(decision:MutableList<Int>, posicionX: Int, posicionY: Int):MutableList<Int> {
        var x = posicionX
        if (decision[0] == 0){
            //Humano
            decision.removeAt(0)
            for (d in decision){
                when (d) {
                    1 -> {
                        TableroJuego[posicionY][x] = "\uD83D\uDD35"
                        x++
                    }

                    2 -> {
                        TableroJuego[posicionY][x] = "\uD83D\uDD34"
                        x++
                    }

                    3 -> {
                        TableroJuego[posicionY][x] = "\uD83D\uDFE2"
                        x++
                    }

                    4 -> {
                        TableroJuego[posicionY][x] = "\uD83D\uDFE1"
                        x++
                    }

                    5 -> {
                        TableroJuego[posicionY][x] = "\uD83D\uDFE0"
                        x++
                    }

                    6 -> {
                        TableroJuego[posicionY][x] = "\uD83D\uDFE3"
                        x++
                    }
                }
            }
            return decision
        } else if(decision[0] == 1){
            //Bot
            decision.removeAt(0)
            return decision
        } else {
            println("Error")
            exitProcess(0)
        }
    }

    fun comprobarMovimiento(eleccion:MutableList<Int>, posicionY: Int){
        //println(Jugador.eleccionBot.botList) -> Muestra la elección del bot
        for (i in Jugador.eleccionBot.botList.indices) {
            if (Jugador.eleccionBot.botList[i] == eleccion[i]){
                TableroAciertos[posicionY][i] = "\u26AA"
            } else {
                TableroAciertos[posicionY][i] = "\u26AB"
            }
        }
    }

    fun comprobarAciertos(posicionY: Int){
        val tablaCompleta = TableroAciertos[posicionY].all { it == "\u26AA" }
        if (tablaCompleta){
            println("**************")
            println("Has ganado!!!!")
            println("**************")
            exitProcess(0)
        }
    }
}