class Jugador(Nombre: String) {
    var Nombre = Nombre
    var isBot = false

    constructor(Nombre: String, isBot: Boolean) : this(isBot.toString()) {
        this.Nombre = Nombre
        this.isBot = isBot
    }

    object eleccionBot{
        var botList = mutableListOf<Int>()
    }

    fun realizarMovimiento(tablero: Tablero):MutableList<Int> {
        var eleccion = mutableListOf<Int>()

        if (this.isBot){
            //Si es bot añade 1 al principio
            eleccion.add(1)
            repeat(tablero.x){
                eleccion.add((1..6).random())
            }
            println("El jugador " + this.Nombre + " ya ha hecho su elección.")
            return eleccion
        } else{
            var posicionX = 0
            var choice = 0
            //si es humano añade 0
            eleccion.add(0)

            do {
                do {
                    println("Introduce un color para la posición " + (posicionX + 1))
                    print("1)Azul 2)Rojo 3)Verde 4)Amarillo 5)Naranja 6)Morado: ")
                    choice = readln().toInt()
                    if (choice !in 1..6) {
                        println("Color desconocido, vuelva a intentarlo...")
                    }
                } while (choice !in 1..6)
                eleccion.add(choice)
                posicionX++
            } while (posicionX != tablero.x)
        }
        return eleccion
    }

    fun jugar(tablero: Tablero){
        var initX = 0
        var initY = tablero.y - 1

        if (this.isBot){
            eleccionBot.botList = tablero.establecerMovimiento(this.realizarMovimiento(tablero),initX, initY)
        } else {
            for (i in 1..tablero.y){
                if (initX == tablero.x){
                    initX = 0
                }
                //eleccion humano
                tablero.comprobarMovimiento(tablero.establecerMovimiento(this.realizarMovimiento(tablero),initX, initY), initY)
                tablero.mostrarTablero()
                tablero.comprobarAciertos(initY)
                initY--
            }
            println("***************")
            println("Has perdido....")
            println("***************")
        }
    }
}