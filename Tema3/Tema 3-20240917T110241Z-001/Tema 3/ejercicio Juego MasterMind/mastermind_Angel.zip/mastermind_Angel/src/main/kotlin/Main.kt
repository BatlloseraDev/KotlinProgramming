fun main() {
//mastermind__Angel Callejas Garcia
    var j = Tablero(7,4)
    j.generarResultado()
    j.mostrar()

    var i = j.tabla.size - 1
    var seguirJuego = true
    while (i >= 0 && seguirJuego) {
        var fila=j.elegirColores()
            for (f in j.tabla[i].indices) {
                j.tabla[i][f]= fila[f].imagen
                j.coinciden(fila,i)
                if(j.esGanador(fila, i)) seguirJuego = false
            }
        i--
        j.mostrar()
    }
}