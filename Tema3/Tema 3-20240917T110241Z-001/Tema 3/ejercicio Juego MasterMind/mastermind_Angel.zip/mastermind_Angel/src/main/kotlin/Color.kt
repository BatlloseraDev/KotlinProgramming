enum class Color(val imagen:String) {
        AMARILLO("\uD83D\uDFE1",),
        NARANJA("\uD83D\uDFE0"),
        AZUL("\uD83D\uDD35"),
        VERDE("\uD83D\uDFE2"),
        ROJO("\uD83D\uDD34");

    }

