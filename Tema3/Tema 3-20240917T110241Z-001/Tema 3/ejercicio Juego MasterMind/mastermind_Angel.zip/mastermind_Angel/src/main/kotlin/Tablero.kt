class Tablero(var largo: Int, var ancho: Int) {
    var tabla = Array(largo) { Array<String>(ancho) {"  "} }
    var tablaResultados = Array(largo) { Array<String>(ancho) {"  "} }
    var resultado = ArrayList<Color>()




    fun mostrar() {

        println()
        for (i in tabla.indices) {
            print("|")
            for (f in tabla[i].indices) {
                print("${tabla[i][f]}|")

            }
            print("  ---> |")
            for (f in tablaResultados[i].indices) {
                print("${tablaResultados[i][f]}|")

            }
            println()
        }

    }
    fun generarResultado(){
        resultado = ArrayList<Color>()
        for (i in 0..<ancho){
            resultado.add(Color.entries.random())
        }


    }
    fun elegirColores():ArrayList<Color>{
        var n = 0
        var lista=ArrayList<Color>()

        while (n<tabla[0].size){
            var numero = 0

            println("elije un color:\n"+
                    "(1.\uD83D\uDFE1)" +
                    "(2.\uD83D\uDFE0)" +
                    "(3.\uD83D\uDD35)" +
                    "(4.\uD83D\uDFE2)" +
                    "(5.\uD83D\uDD34)")

                do {
                    numero = readln().toInt()
                    if (numero>5||numero<1){
                        println("numero no valido")
                    }
                }while (numero>5||numero<1)

                when (numero){
                    1->lista.add(Color.AMARILLO)
                    2->lista.add(Color.NARANJA)
                    3->lista.add(Color.AZUL)
                    4->lista.add(Color.VERDE)
                    5->lista.add(Color.ROJO)
                }

            n++
        }

        return lista
    }
    fun coinciden(lista: ArrayList<Color>, posicion: Int) {
        for (i in lista.indices) {
            if (lista[i] == resultado[i]) {
                tablaResultados[posicion][i] = "✅"
            } else if (resultado.contains(lista[i])) {
                tablaResultados[posicion][i] = "☑️"
            } else {
                tablaResultados[posicion][i] = "❌"
            }
        }
    }

    fun esGanador(lista : ArrayList<Color>, posicion : Int) : Boolean {
        var esGanador = true
        for(i in lista.indices){
            if (tablaResultados[posicion][i] != "✅") esGanador = false
        }
        return esGanador
    }



}
