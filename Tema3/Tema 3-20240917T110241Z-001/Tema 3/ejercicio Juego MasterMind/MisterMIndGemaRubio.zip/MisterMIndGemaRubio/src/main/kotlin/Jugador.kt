class Jugador {
    var nombre=""
    var puntuacion=0
    var combinacionElegida=Array(4){0}

    constructor(nombre:String){
        this.nombre=nombre
    }
    override fun toString(): String {
        return "$nombre Puntuacion: $puntuacion"
    }
    fun pedirCombinacion(tablero:Tablero){
        var i=0
        do {
            println("Dime el color del lugar $i:\n Rojo-> 1\n Naranja-> 2\n Azul-> 3\n Verde-> 4\n Morado-> 5\n Gris-> 6")

                combinacionElegida[i]= readln().toInt()
            if (tablero.comprobarCombinacion(combinacionElegida[i])) {
                tablero.combinacionColores[tablero.ronda][i] = combinacionElegida[i]
                i++

            }else println("eleccion no valida")


        }while (i<combinacionElegida.size)

    }
    fun imprimirCombinacionElegida(){
        for (i in combinacionElegida){
            print("[$i]")
        }
    }

}