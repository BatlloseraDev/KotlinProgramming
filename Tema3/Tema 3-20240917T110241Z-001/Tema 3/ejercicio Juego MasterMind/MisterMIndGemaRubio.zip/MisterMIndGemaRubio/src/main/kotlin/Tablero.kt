class Tablero {
    var combinacionColores: Array<Array<Int>>
    var tamanio = 0
    var pistas: Array<Array<String>>
    var tamanioPistas = 0
    var intentos = 0
    var solucion: Array<Int>
    var ronda = 0
    var tableroColores= arrayOf("_","R","N","A","V","M","G")

    constructor(tamanio: Int, tamanioPistas: Int, intentos: Int) {
        this.tamanio = tamanio
        this.tamanioPistas = tamanioPistas
        this.intentos = intentos
        this.combinacionColores = Array(this.intentos) { Array(this.tamanio) { 0 } }
        this.pistas = Array(this.intentos){ Array(this.tamanioPistas) { "[_]" }}
        this.solucion = Array(this.tamanio) { 0 }

    }

    fun imprimirSolucion(){
        for (i in 0..<solucion.size){
            print("[${tableroColores[solucion[i]]}]")
        }
        println()
    }
    fun imprimirTablero() {

        for (i in 0..<combinacionColores.size) {
            for (j in 0..<combinacionColores[i].size) {

                print("[${tableroColores[combinacionColores[i][j]]}]")

            }
            print("   ")
            var k=pistas[i].size-1
            while(k>=0) {
                if (k==1){
                    println()
                    print("               ")
                }
                print(pistas[i][k])
                k--
            }
            /*for (k in 0..<pistas[i].size ) {

                print(pistas[i][k])
            }*/

            println()
            println()
        }

    }

    fun crearSolucion() {
        for (i in 0..<solucion.size) {
            solucion[i] = (1..6).random()


        }
        var i=0


    }

    fun coincideCombinacion(jugador: Jugador): Boolean {
        var correcto = false
        var cantidadAciertos=0

        for(i in 0..< jugador.combinacionElegida.size) {
            if (jugador.combinacionElegida[i] == solucion[i]) {
                cantidadAciertos++

            }
        }

        if (cantidadAciertos==4){
            correcto=true
            jugador.puntuacion++
        }
        return correcto
    }
    fun comprobarCombinacion(combinacionElegida:Int):Boolean{
        var combinacionValida=false
        //for (i in 0..<combinacionElegida.size){
        if(combinacionElegida>0 && combinacionElegida<7 ){
            combinacionValida=true
            }
        //}
        return combinacionValida
    }
    fun darPista(combinacionElegida: Array<Int>){
        //blanco=color y posicion correctas
        //negro=color correcto posicion mal
        //gris=color y posicion mal
        var blancas=10
        for (i in 0..<combinacionElegida.size){
            if (combinacionElegida[i]==solucion[i]){
                pistas[ronda][i]="[B]"
                blancas=i
            }else {
                for (j in 0..<solucion.size){
                   if (combinacionElegida[i]==solucion[j] && j!=blancas) {

                       pistas[ronda][i]="[N]"
                   }
                }
            }
        }
    }
fun finJuego():Boolean{
    var seguir=false
    if (ronda<intentos){
        seguir=true
    }
    return seguir
}
}