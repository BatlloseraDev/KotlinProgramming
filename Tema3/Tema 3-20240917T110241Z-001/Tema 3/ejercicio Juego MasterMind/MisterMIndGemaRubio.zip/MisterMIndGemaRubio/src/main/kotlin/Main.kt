fun main(args: Array<String>) {
    var jugador1=Jugador("Gema")
    var jugador2=Jugador("David")
    var tablero=Tablero(4,4,8)
    tablero.crearSolucion()
    tablero.imprimirTablero()

        do {

            if(tablero.coincideCombinacion(jugador1) || tablero.coincideCombinacion(jugador2)) {
            tablero.ronda=tablero.intentos
            }else {

                
                jugador1.pedirCombinacion(tablero)
                tablero.darPista(jugador1.combinacionElegida)
                tablero.imprimirTablero()
                tablero.ronda++
                println("Ronda: ${tablero.ronda}")
                if(tablero.coincideCombinacion(jugador1) || tablero.coincideCombinacion(jugador2)) {
                    tablero.ronda=tablero.intentos
                }else{
                    jugador2.pedirCombinacion(tablero)
                    tablero.darPista(jugador2.combinacionElegida)
                    tablero.imprimirTablero()
                    tablero.ronda++
                    println("Ronda: ${tablero.ronda}")
                }

            }
        }while (tablero.finJuego() )

        tablero.imprimirSolucion()

        println("Marcador:\n ${jugador1.toString()}\n${jugador2.toString()}")










}