fun main(args: Array<String>) {
    var tablero = Tablero()
    var jugador = Jugador()

    var contadorIntentos = 0


    println("El juego trata de adivina una lista de colores (en este caso 4 colores) en menos de 7 intentos.")
    println("  Los colores son: naranja, rojo, azul, amarillo, morado y verde")

    tablero.crearCodigoSecreto()
    do {
        tablero.imprimirTablero()
        tablero.hacerIntento(jugador.decirColor())

    }while ((!tablero.esCorrecto()) || (contadorIntentos >= 7))



}