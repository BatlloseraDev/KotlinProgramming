enum class Colores (valor: Int){
    NARANJA(0),
    ROJO(1),
    AZUL(2),
    AMARILLO(3),
    MORADO(4),
    VERDE(5)

}