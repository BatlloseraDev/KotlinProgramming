class Tablero () {
    var codigoSecreto : Array<String> = Array(4){"_"}
    var pista = ""
    //crear tablero
    var tamanio = 7
    var matriz = Array(tamanio){Array(4){"_"} }
    var intentosJugador = 0
    //comprobar acierto
    var contLetrasAcertadas = 0
    var codigoAdivinado = false

    fun imprimirTablero(){
        pista= " "
        for (i in matriz){
            for (j in i ){
                print("[ ${j} ]")

            }
            print("--> Pista: ")
            darPista(i)

            println()
        }

    }

    fun hacerIntento(intento : Array<String>) {
        matriz[intentosJugador++] = arrayOf(intento[0], intento[1], intento[2], intento[3])

    }

    fun crearCodigoSecreto(): Array<String>{
        //crear el codigo
        for (i in codigoSecreto.indices){
            codigoSecreto[i] = Colores.values().random().toString()
        }

        return codigoSecreto
    }

    fun darPista(seleccion: Array<String>): Int{
        contLetrasAcertadas = 0

        for (color in this.codigoSecreto.indices){
            if (this.codigoSecreto[color].equals(seleccion[color])){ // el color y la posicion son correctos
                pista = "=" //blanco
                this.contLetrasAcertadas++ // si el color es igual, suma

            }else if (this.codigoSecreto.contains(seleccion[color])){ // el color es correcto pero la posicion incorrecta
                pista = "o" // negro
                this.contLetrasAcertadas = 0 //sino, resta

            }else{ // no se encuentra el color dentro del codigo secreto
                pista = "_"
                this.contLetrasAcertadas = 0
            }
            print(pista)
        }

        return this.contLetrasAcertadas
    }

    fun esCorrecto(): Boolean{
        if (this.contLetrasAcertadas == 4){
            this.codigoAdivinado = true

            println("¡¡ Enhorabuena !!")
            print("El codigo secreto es:  ")
            //imprimir color
            for (color in codigoSecreto.indices){
                print("[ ${codigoSecreto[color]} ]")
            }
            println()

        }else{
            this.codigoAdivinado = false
        }

        return this.codigoAdivinado
    }
    





}