class Jugador {
    var intento: Array<String> = Array(4){""}
    var puntuacion = 0
    var partidasJugadas = 0

    //colocar colores en el tablero
    var contadorFila = 0
    var contadorColumna = 0

    constructor()

    fun decirColor(): Array<String>{

        println("Escribe 4 colores uno por uno")

        do {
            print(" -> primer color: ")
            intento[0] = readln().toString().trim().uppercase()
        }while (intento[0] != "NARANJA" && intento[0] != "ROJO" && intento[0] != "AZUL" && intento[0] != "AMARILLO" && intento[0] != "MORADO" && intento[0] != "VERDE")

        do {
            print(" -> Segundo color: ")
            intento[1] = readln().toString().trim().uppercase()
        }while (intento[1] != "NARANJA" && intento[1] != "ROJO" && intento[1] != "AZUL" && intento[1] != "AMARILLO" && intento[1] != "MORADO" && intento[1] != "VERDE")

        do {
            print(" -> Tercer color: ")
            intento[2] = readln().toString().trim().uppercase()
        }while (intento[2] != "NARANJA" && intento[2] != "ROJO" && intento[2] != "AZUL" && intento[2] != "AMARILLO" && intento[2] != "MORADO" && intento[2] != "VERDE")

        do {
            print(" -> Último color: ")
            intento[3] = readln().toString().trim().uppercase()
        }while (intento[3] != "NARANJA" && intento[3] != "ROJO" && intento[3] != "AZUL" && intento[3] != "AMARILLO" && intento[3] != "MORADO" && intento[3] != "VERDE")


        return intento
    }


}