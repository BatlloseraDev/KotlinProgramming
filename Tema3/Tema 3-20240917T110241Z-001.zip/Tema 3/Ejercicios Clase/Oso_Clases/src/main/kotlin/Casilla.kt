class Casilla {
    var fila=0
    var columna=0

    constructor(fila:Int, c:Int){
        this.fila = fila
        columna = c
    }
}