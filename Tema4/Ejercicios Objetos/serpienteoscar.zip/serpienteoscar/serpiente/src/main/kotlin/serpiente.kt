class serpiente {
    var cuerpo = ArrayList<anilla>(3)
    var edad = 0
    var viva = true

    companion object {
        var cantidad = 0
    }

    constructor() {
        cantidad++
    }

    fun cumpleAños() {
        edad++
    }

    fun decrece() {
        cuerpo.removeAt(0)
    }

    fun crece() {
        cuerpo.add(anilla())

    }

    fun comprobarEdad(): Int {
        return edad
    }

    fun cambiarPiel() {
        var i = 0
        while (i < cuerpo.size) {
            cuerpo[i].cambiaColor()
            i++
        }

    }

    fun ataque() {
        viva = false
    }
}
