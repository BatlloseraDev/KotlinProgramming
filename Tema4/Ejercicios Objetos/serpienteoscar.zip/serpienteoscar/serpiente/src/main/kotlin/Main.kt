import kotlin.concurrent.thread
import kotlin.random.Random

fun main(args: Array<String>) {

    var nido=ArrayList<serpiente>()
    while (serpiente.cantidad<20){
        var ser=serpiente()
        nido.add(ser)
    }
    var i=0
    while (i<300){
        //Thread.sleep(1000)
        var i2=0
        while(i2<nido.size){
            nido[i2].cumpleAños()
            if (nido[i2].edad<10){
                var i3=(1..10).random()
                when(i3){
                    in 1..8 -> nido[i2].crece()
                    else -> nido[i2].cambiarPiel()
                }
            }else{
                var i3=(1..10).random()
                when(i3){
                    in 1..9 -> nido[i2].decrece()
                    else -> nido[i2].cambiarPiel()
                }
            }

            i2++
        }
        i++
    }
    //var i4= Random.nextInt(0,nido.size)
    //nido.removeAt(i4)

}

