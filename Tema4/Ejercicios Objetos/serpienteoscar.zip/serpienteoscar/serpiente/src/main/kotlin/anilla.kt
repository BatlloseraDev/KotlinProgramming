class anilla {
    var gama="rva"

    var color=' '

    constructor(){
        color=gama[(0..(gama.length-1)).random()]
    }

    fun cambiaColor(){
        color=gama[(0..(gama.length-1)).random()]
    }
}
