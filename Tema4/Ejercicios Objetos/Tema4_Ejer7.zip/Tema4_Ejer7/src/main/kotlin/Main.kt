fun main() {
    //variables
    var seHaMovido: Boolean
    var golpeo:Int
    var cont= 0
    var estaMuerta = false


    val miTablero = Tablero()

    // inicio
    miTablero.iniciarTablero()
    miTablero.mostarVector()
    println("Tablero Iniciado")
    println(miTablero.mostarVector())
    miTablero.colocarMosca()
    println(miTablero.mostarVector())
    println("Mosca lista")

    while (!estaMuerta && cont < 5) {
        println("Donde golpeas?")
        println(miTablero.mostarVectorUser())
        golpeo = readln().toInt()
        estaMuerta = miTablero.laHasMatado(golpeo)

        if (estaMuerta) {
            println("Mosca Muerta")
            miTablero.setMosca(miTablero.getMosca() - 1)
            println("Quedan: " + miTablero.getMosca() + " Moscas")
            if (miTablero.getMosca() > 0) {
                estaMuerta = false
                miTablero.iniciarTablero()
                miTablero.colocarMosca()
                println(miTablero.mostarVector())
                println("Todas las demas moscas se han movido")
            } else {
                miTablero.iniciarTablero()
                println("Conseguido en: $cont intentos.")
                println(miTablero.mostarVector())
            }

        } else {
            seHaMovido = miTablero.seMovio(golpeo)
            cont++
            if (seHaMovido) {
                println("Estaba cerca! Pero se ha movido")
                miTablero.colocarMosca()
            } else {
                println("Ni se ha inmutado")
            }
        }
    }

    if (!estaMuerta) {
        println("Te has quedado sin intentos")
        println("Estaba aqui")
        println(miTablero.mostarVector())
    }
}
