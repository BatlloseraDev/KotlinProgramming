class Tablero {
    //------------variables--------------------------------
    private var tamanno: CharArray
    private var mosca = 0

    constructor() {
        tamanno = CharArray(5)
        mosca = 1
    }

    constructor(tamanno: Int, mosca: Int) {
        this.tamanno = CharArray(tamanno)
        this.mosca = mosca
    }

    //getters y setters

    //getters y setters
    fun getMosca(): Int {
        return mosca
    }

    fun setMosca(mosca: Int) {
        this.mosca = mosca
    }

    //metodos publicos
    fun iniciarTablero() {
        for (i in tamanno.indices) {
            tamanno[i] = '-'
        }
    }

    fun colocarMosca() {
        var cont = 0
        while (cont < mosca) {
            val alea = (Math.random() * tamanno.size).toInt()
            if (tamanno[alea] != 'M') {
                tamanno[alea] = 'M'
                cont++
            }
        }
    }

    fun laHasMatado(golpeo: Int): Boolean {
        var estaMuerta = false
        for (i in tamanno.indices) {
            if (golpeo == i) {
                if (tamanno[i] == 'M') {
                    estaMuerta = true
                }
            }
        }
        return estaMuerta
    }

    fun seMovio(golpeo: Int): Boolean {
        var seMovio = false
        if (golpeo == 0) {
            if (tamanno[golpeo + 1] == 'M') {
                seMovio = true
            }
        }
        if (golpeo == tamanno.size - 1) {
            if (tamanno[golpeo - 1] == 'M') {
                seMovio = true
            }
        }
        if (golpeo != 0 && golpeo != (tamanno.size - 1)) {
            if (tamanno[golpeo - 1] == 'M' || tamanno[golpeo + 1] == 'M') {
                seMovio = true
            }
        }
        return seMovio
    }

    fun mostarVector(): String {
        var mostrar = ""
        for (i in tamanno.indices) {
            mostrar += tamanno[i].toString() + " "
        }
        mostrar += "\n"
        return mostrar

    }

    fun mostarVectorUser(): String {
        var mostrar = ""
        for (i in tamanno.indices) {
            mostrar += "$i  "
        }
        mostrar += "\n"
        return mostrar
    }

    override fun toString(): String {
        return "Tablero{tamanno=$tamanno}"
    }

}