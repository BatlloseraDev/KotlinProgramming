fun main(args: Array<String>) {
    var a0: Persona
    a0=Persona(3)
   var a1 = Persona2(7)
   var a2 = Persona2(2,"Pepe")
    a1.setnombre("Juan")
    a1.altura = 7 // ERROR DE CONCEPTO DE PROGRAMACION ORIENTADA A OBJETOS PURA.




    var a3 = Persona(3,"Ana",23)


    print( a3.toString())

    a1.presentacion()
    a2.presentacion()

    var micasa = Casa(a3,a1)
    micasa.DatosMatrimonio()
}