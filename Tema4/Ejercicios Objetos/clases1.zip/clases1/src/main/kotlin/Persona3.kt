class Persona3 private constructor(var edad: Int, var nombre: String, var altura: Int) {
}