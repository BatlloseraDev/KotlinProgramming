class Reloj {
    private var hora:Int  = 0
    private var minuto:Int  = 0
    private var segundos:Int = 0
    private var pila:Int = 1000
    private var modo:String = ""

    constructor(){
        this.hora = 12;
        this.minuto = 0;
        this.segundos = 0;
        modo = "24";
    }
    constructor(hora:Int,minuto:Int, segundos:Int){
        this.hora = hora;
        this.minuto = minuto;
        this.segundos = segundos;
        modo = "24";
    }
    fun getHora():Int {
        return hora;
    }

    fun getMinuto():Int {
        return minuto;
    }

    fun getSegundos():Int {
        return segundos;
    }

    fun getPila():Int {
        return pila;
    }
    fun getModo():String {
        return modo;
    }

    fun setHora(hora:Int) {
        this.hora = hora;
    }

    fun setMinuto(minuto:Int) {
        this.minuto = minuto;
    }

    fun setSegundos(segundos:Int) {
        this.segundos = segundos;
    }

    fun setModo(tipo:String) {
        if (tipo.equals(12)){
            this.modo = tipo;
        }else{
            this.modo = "24";
        }

    }

    override fun toString(): String {
        //return "Reloj(hora=$hora, minuto=$minuto, segundos=$segundos, pila=$pila, modo='$modo')"
        //return "$hora:$minuto:$segundos, pila=$pila, modo='$modo')"
        var h:String
        var m:String
        var s:String

        if (modo.equals("12") && hora>12){
            var aux:Int = hora
            aux = hora-12
            if (aux.toString().length < 2){
                h="0"+aux
            }else{
                h=aux.toString()
            }
        }else{
            if (hora.toString().length < 2){
                h="0"+hora
            }else{
                h=hora.toString()
            }
        }

        if (minuto.toString().length < 2){
            m="0"+minuto
        }else{
            m=minuto.toString()
        }
        if (segundos.toString().length < 2){
            s="0"+segundos
        }else{
            s=segundos.toString()
        }
        return "$h:$m:$s"
    }

    fun recargarPila() {
        pila = 1000
    }

    fun ticTac() {
        segundos++
        if (segundos == 60) {
            segundos = 0
            minuto++
        }
        if (minuto == 60) {
            minuto = 0
            hora++
        }
        if (hora == 24) {
                hora = 0
                minuto = 0
                segundos = 0
        }
        pila--
    }

    fun tienePila(): Boolean {
        return pila > 0
    }

}