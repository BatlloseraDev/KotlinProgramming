fun main() {
    var r2 = Reloj2()
    r2.hora = 13
    r2.minuto = 59
    r2.segundos = 59
    r2.modo = "30"
    print(r2.hora)

    var r3 = Reloj()
    r3.setHora(13)
    r3.setMinuto(59)
    r3.setSegundos(59)
    r3.setModo("24")

    print(r3.getHora())

    /* con la clase de java
    val r = Reloj(13, 59, 59)
    var letra:Char
    println(r)
    //println(r.toString())


    while (r.tienePila()) {
        r.ticTac()
        println(r)
        Thread.sleep(100000)
        if (!r.tienePila()) {
            println("Te has quedado sin pilas")
            print("¿Quieres recargar la pila? (S/n): ")
            letra = readLine().toString()[0]
            if (letra == 'S' || letra == 's') {
                r.recargarPila()
            }
        }
    }*/
}