fun main(args: Array<String>) {
    var q1 = Punto()


   // var q2 = Punto(2,3)
   // var q3 = Punto(7)

    q1.x = 7
    println(q1.x)
}