class Punto {
    var x:Int = 0
    private var y:Int = 0
}