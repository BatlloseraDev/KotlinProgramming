enum class Tipo {
    SINDEFINIR,
    BARCO,
    COCHE,
    BICICLETA;
}