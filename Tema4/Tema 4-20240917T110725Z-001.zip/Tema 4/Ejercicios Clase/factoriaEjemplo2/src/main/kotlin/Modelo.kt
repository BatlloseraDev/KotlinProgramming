enum class Modelo {
    SINMODELO,
    SEAT,
    FERRARI,
    VOLVO;
}