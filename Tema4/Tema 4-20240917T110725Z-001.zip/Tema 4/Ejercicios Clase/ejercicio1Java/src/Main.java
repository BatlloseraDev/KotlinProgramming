public class Main {
    public static void main(String[] args) {
        Punto q1 =new Punto();
        q1.x=8;

        q1.setX(8);

        q1.setY(6);
    }
}