fun main(args: Array<String>) {
    val miCoche = Coche("Toyota", "Corolla", 2019)
    println("Marca: ${miCoche.marca}")
    println("Modelo: ${miCoche.modelo}")
    println("Año: ${miCoche.año}")

    miCoche.
    miCoche.frenar()

    val antiguedad = miCoche.obtenerAntiguedad()
    println("Antigüedad del coche: $antiguedad años")
}
fun imprimir(){}