import kotlin.random.Random

fun main(args: Array<String>) {
    for (i in 1 ..10){
        var v = Factoria.devolverVehiculo()
        println(v)
    }
    
}