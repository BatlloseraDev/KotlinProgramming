enum class Efectividad(var valor:Double, var nombre:String) {
    SUPEREFECTIVO(2.0,"Super efectivo"),
    NEUTRAL(1.0,"Neutral"),
    POCOEFECTIVO(0.5,"no es muy efectivo");
}