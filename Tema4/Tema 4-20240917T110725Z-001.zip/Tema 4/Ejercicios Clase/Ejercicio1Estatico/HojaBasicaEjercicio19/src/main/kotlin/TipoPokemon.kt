enum class TipoPokemon() {
    AGUA,
    FUEGO,
    PLANTA,
    ELECTRICO;
}