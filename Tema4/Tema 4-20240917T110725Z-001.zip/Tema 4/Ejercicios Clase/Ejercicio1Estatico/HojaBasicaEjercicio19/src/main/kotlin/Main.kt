fun main(args: Array<String>) {
    Batalla.batallaPokemon(Pokemon(TipoPokemon.AGUA),Pokemon(TipoPokemon.AGUA))
}