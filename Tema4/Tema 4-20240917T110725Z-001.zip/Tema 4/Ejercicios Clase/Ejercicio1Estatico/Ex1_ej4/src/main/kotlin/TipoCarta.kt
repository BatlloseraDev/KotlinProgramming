enum class TipoCarta {
    DRAGONES,
    HEROES,
    LUGARES;
}