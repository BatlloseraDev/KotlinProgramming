fun main(args: Array<String>) {
    var texto = Consola.leerTexto("Por favor, ingresa un texto: ")
    Consola.escribirTexto("El texto ingresado es: $texto")

    var numero = Consola.leerEntero("Por favor, ingresa un número entero: ")
    Consola.escribirEntero(numero)
}





