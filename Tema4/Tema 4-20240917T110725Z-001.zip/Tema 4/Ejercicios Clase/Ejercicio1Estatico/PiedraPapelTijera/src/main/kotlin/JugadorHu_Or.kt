class JugadorHu_Or {
}