enum class Material {
    PLASTICO,
    LATON;
}