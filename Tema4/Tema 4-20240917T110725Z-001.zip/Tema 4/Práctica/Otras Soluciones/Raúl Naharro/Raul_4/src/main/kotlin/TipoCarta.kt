enum class TipoCarta {
    HEROE,
    DRAGON,
    LUGAR
}