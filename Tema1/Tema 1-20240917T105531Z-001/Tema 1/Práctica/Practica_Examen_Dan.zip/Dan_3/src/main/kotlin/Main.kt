import kotlin.math.truncate

fun main() {
    //Daniel Cruz Villegas | 1ºDAW
    var caracter : String
    var cifras : Int
    var valorAscii : Int

    do {
        do {
            caracter = pedirCaracter()
            valorAscii = convertirEnAscii(caracter)
            cifras = numeroCifras(valorAscii)
        } while (cifras > 3)

        pasarAChar(caracter,valorAscii)
    } while (terminar())

}
fun pedirCaracter(): String {
    println("Introduce un único carácter:")
    val caracter : String = readln().lowercase()
    return caracter
}
fun convertirEnAscii(caracter: String): Int {
    val valorAscii = caracter.hashCode()
    return valorAscii
}
fun numeroCifras(caracter: Int): Int {
    var num = caracter.toDouble()
    var cifras : Int = 0
    while (num != 0.0) {
        num = truncate(num / 10)
        cifras++
    }
    return cifras
}
fun pasarAChar(caracter: String, valorAscii: Int) {
    var palabra = caracter
    var i : Int = 0

    when (valorAscii) {
        97 -> println("e")
        101 -> println("i")
        105 -> println("o")
        111 -> println("u")
        117 -> println("a")
        in 97..122 -> {

            while (i < 3) {
                val random = (97..122).random().toChar()
                palabra += random
                i++
            }
            println(palabra)
        }
        else -> {
            println("El valor en ASCII del carácter '$caracter' es $valorAscii.")
        }
    }
}
fun terminar(): Boolean {
    val respuesta : String
    var terminar : Boolean = false
    println("¿Desea terminar? (S/N)")
    respuesta = readln().uppercase()
    if (respuesta != "S") {
        terminar = true
    }
    return terminar
}
