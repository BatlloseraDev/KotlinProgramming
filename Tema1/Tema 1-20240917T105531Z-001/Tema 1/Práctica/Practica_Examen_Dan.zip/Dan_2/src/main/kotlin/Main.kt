import kotlin.math.round

fun main() {
    //Daniel Cruz Villegas | 1ºDAW
    var contadorSimulacion = 1
    var hayRiego = 0
    var hayRadiacion = 0
    var noCumpleControl = 0
    var humedadAireBaja : Int = 0
    var humedadAireAlta : Int = 0

    println("Simulación de riego de cultivos\n---------")
    println("¿Cuántas veces quieres realizar la simulación?")
    val numeroSimulacion = readln().toInt()

    do {
        val humedadSuelo = saberHumedadSuelo()
        val radiacion = saberRadiacion()
        val humedadAire = saberHumedadAire()
        val crecimiento = saberCrecimiento()
        val humedadSueloString = miStringHumedadSuelo(humedadSuelo)
        val radiacionString = miStringRadiacion(radiacion)
        val humedadAireString = miStringHumedadAire(humedadAire)
        val crecimientoString = miStringCrecimiento(crecimiento)

        println("Simulación nº$contadorSimulacion:")
        //println("$humedadSuelo $radiacion $humedadAire $crecimiento")

        if (humedadSuelo == 1 && radiacion == 1 && humedadAire == 2 && crecimiento == 1) {
            println("$humedadSueloString | $radiacionString | $humedadAireString | $crecimientoString \nSe riega dos veces.")
            noCumpleControl = 0
        }
        else if ((humedadSuelo == 1 || radiacion == 1) && (humedadAire == 1 || crecimiento == 1)) {
            println("$humedadSueloString | $radiacionString | $humedadAireString | $crecimientoString \nSe riega.")
            noCumpleControl = 0
        }
        else if ((humedadSuelo == 2 || radiacion == 2 || humedadAire == 2) && (crecimiento == 2)) {
            println("$humedadSueloString | $radiacionString | $humedadAireString | $crecimientoString \nNo se riega.")
            noCumpleControl = 0
        }
        else if ((humedadSuelo == 3 || radiacion == 2) && (humedadAire == 2 || crecimiento == 2)) {
            println("$humedadSueloString | $radiacionString | $humedadAireString | $crecimientoString")
            noCumpleControl = 0
            if (hayRiego == 0) {
                println("Sin riego.")
                hayRiego++
            } else {
                println("Con riego")
                hayRiego = 0
            }
        }
        else {
            println("No se cumple ningún control de la empresa.")
            noCumpleControl++
        }

        if (radiacion == 2 && (humedadSuelo == 1 && humedadAire == 1)) {
            hayRadiacion++
        } else {
            hayRadiacion = 0
        }

        when (humedadAire) {
            1 -> humedadAireBaja++
            2 -> humedadAireAlta++
        }

        contadorSimulacion++
    } while (contadorSimulacion <= numeroSimulacion && noCumpleControl != 2 && hayRadiacion != 2)

    val totalHumedadAireBaja = estadisticasHumedadAireBaja(humedadAireBaja.toDouble(),contadorSimulacion-1.toDouble())
    val totalHumedadAireAlta = estadisticasHumedadAireAlta(humedadAireAlta.toDouble(),contadorSimulacion-1.toDouble())

    println("-----------\nHa habido un $totalHumedadAireBaja% de humedad baja en el aire en las ${contadorSimulacion-1} simulaciones.")
    println("Ha habido un $totalHumedadAireAlta% de humedad alta en el aire en las ${contadorSimulacion-1} simulaciones.")

}

fun saberHumedadSuelo() : Int {
    val valor = (1..3).random()
    return valor
}
fun miStringHumedadSuelo(h : Int) : String {
    var hString = h.toString()
    when (h) {
        1 -> hString = "Humedad suelo: baja"
        2 -> hString = "Humedad suelo: media"
        3 -> hString = "Humedad suelo: alta"
    }
    return hString
}
fun saberRadiacion() : Int {
    val valor = (1..2).random()
    return valor
}
fun miStringRadiacion(r : Int) : String {
    var rString = r.toString()
    when (r) {
        1 -> rString = "Radiación: baja"
        2 -> rString = "Radiación: alta"
    }
    return rString
}
fun saberHumedadAire() : Int {
    val valor = (1..2).random()
    return valor
}
fun miStringHumedadAire(h2 : Int) : String {
    var h2String = h2.toString()
    when (h2) {
        1 -> h2String = "Humedad aire: baja"
        2 -> h2String = "Humedad aire: alta"
    }
    return h2String
}
fun saberCrecimiento() : Int {
    val valor = (1..2).random()
    return valor
}
fun miStringCrecimiento(c : Int) : String {
    var cString = c.toString()
    when (c) {
        1 -> cString = "Crecimiento: insuficiente"
        2 -> cString = "Crecimiento: suficiente"
    }
    return cString
}
fun estadisticasHumedadAireBaja(humedadAireBaja : Double, contadorSimulacion : Double): Int {
    val totalHumedadBaja = round(humedadAireBaja / contadorSimulacion * 100).toInt()

    return totalHumedadBaja
}
fun estadisticasHumedadAireAlta(humedadAireAlta : Double, contadorSimulacion: Double): Int {
    val totalHumedadAlta = round(humedadAireAlta / contadorSimulacion * 100).toInt()
    return totalHumedadAlta
}