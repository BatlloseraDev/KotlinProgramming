fun main() {
    //Daniel Cruz Villegas | 1ºDAW
    val numeroSimulacion : Int
    var contadorSimulacion : Int = 1
    var hayRiego = 0

    println("Simulación de riego de cultivos\n---------")
    println("¿Cuántas veces quieres realizar la simulación?")
    numeroSimulacion = readln().toInt()

    do {
        val humedadSuelo = saberHumedadSuelo()
        val radiacion = saberRadiacion()
        val humedadAire = saberHumedadAire()
        val crecimiento = saberCrecimiento()
        val humedadSueloString = miStringHumedadSuelo(humedadSuelo)
        val radiacionString = miStringRadiacion(radiacion)
        val humedadAireString = miStringHumedadAire(humedadAire)
        val crecimientoString = miStringCrecimiento(crecimiento)

        println("Simulación nº$contadorSimulacion:")

        if (humedadSuelo == 1 && radiacion == 1 && humedadAire == 2 && crecimiento == 1) {
            println("$humedadSueloString | $radiacionString | $humedadAireString | $crecimientoString \nSe riega dos veces.")
        }
        else if ((humedadSuelo == 1 || radiacion == 1) && (humedadAire == 1 || crecimiento == 1)) {
            println("$humedadSueloString | $radiacionString | $humedadAireString | $crecimientoString \nSe riega.")
        }
        else if ((humedadSuelo == 2 || radiacion == 2 || humedadAire == 2) && (crecimiento == 2)) {
            println("$humedadSueloString | $radiacionString | $humedadAireString | $crecimientoString \nNo se riega.")
        }
        else if ((humedadSuelo == 3 || radiacion == 2) && (humedadAire == 2 || crecimiento == 2)) {
            println("$humedadSueloString | $radiacionString | $humedadAireString | $crecimientoString")
            if (hayRiego == 0) {
                println("Sin riego.")
                hayRiego++
            } else {
                println("Con riego")
                hayRiego = 0
            }
        }
        else {
            println("No se cumple ningún control de la empresa.")
        }
        contadorSimulacion++
    } while (contadorSimulacion <= numeroSimulacion)
}

fun saberHumedadSuelo() : Int {
    val valor = (1..3).random()
    return valor
}
fun miStringHumedadSuelo(h : Int) : String {
    var hString = h.toString()
    when (h) {
        1 -> hString = "Humedad suelo: baja"
        2 -> hString = "Humedad suelo: media"
        3 -> hString = "Humedad suelo: alta"
    }
    return hString
}
fun saberRadiacion() : Int {
    val valor = (1..2).random()
    return valor
}
fun miStringRadiacion(r : Int) : String {
    var rString = r.toString()
    when (r) {
        1 -> rString = "Radiación: baja"
        2 -> rString = "Radiación: media"
    }
    return rString
}
fun saberHumedadAire() : Int {
    val valor = (1..2).random()
    return valor
}
fun miStringHumedadAire(h2 : Int) : String {
    var h2String = h2.toString()
    when (h2) {
        1 -> h2String = "Humedad aire: baja"
        2 -> h2String = "Humedad aire: media"
    }
    return h2String
}
fun saberCrecimiento() : Int {
    val valor = (1..2).random()
    return valor
}
fun miStringCrecimiento(c : Int) : String {
    var cString = c.toString()
    when (c) {
        1 -> cString = "Crecimiento: insuficiente"
        2 -> cString = "Crecimiento: suficiente"
    }
    return cString
}