fun main(args: Array<String>) {
  //Gema Rubio Sánchez
    println("cuantas veces")
    var n= readln().toInt()
    var contador=0
    var regado=0
    var contradiacion=0
    var contvecesseguidas=0
    var conthumedadaire=0
    while (contador<=n && contradiacion< 2 && contvecesseguidas<2){
        var humedadsuelo=sensor(1,3)
        println("la humedad del suelo es $humedadsuelo")
        var radiacion=sensor(1,2)
            if (radiacion==2){
                contradiacion++
            }
        println("la radiacion es $radiacion")
        var humedadaire=sensor(1,2)
        println("la humedad del aire es $humedadaire")
        if (humedadaire==2){
            conthumedadaire++
        }
        var crecimiento=sensor(1,2)
        println("el crecimiento es $crecimiento")
        regado=seriega(humedadsuelo,radiacion,humedadaire,crecimiento,regado)

        if (regado==3){
            contvecesseguidas++
        }else{
            contvecesseguidas=0
        }
        contador++
    }
    var probabilidadaire=probabilidad(contador,conthumedadaire)
    println("La humedad del aire es alta un $probabilidadaire % de las veces ")
}

fun sensor(minimo:Int, maximo:Int):Int{
    var sensor= (minimo..maximo).random()
    return sensor
}


fun seriega(humedadsuelo: Int,radiacion: Int,humedadaire: Int,crecimiento: Int,regado:Int):Int {
    var baja=1
    var media=3
    var alta=2
    var suficiente=1
    var insuficiente=2
    var riego=regado

    if (humedadsuelo==baja && radiacion==baja && humedadaire==alta && crecimiento==insuficiente){
        println("se riega dos veces")
        riego=1
    }else if ((humedadsuelo==baja || radiacion==baja)&&(humedadaire==baja||crecimiento==insuficiente)){
           riego=1
           println("se riega ")
    } else if ((humedadsuelo==media || radiacion==alta || humedadaire==alta) && (crecimiento==suficiente)) {
            println("sin riego")
            riego = 2
    }else if ((humedadsuelo == alta || radiacion == alta) && (humedadaire == alta || crecimiento == suficiente)) {
       if (riego == 2) {
           println("hay que regar")
           riego = 1
       } else {
           println("no se riega hoy")
       }

   }else{
       println("no se ha cumplido ninguna condicion")
        riego=3
   }
    return riego
}

fun probabilidad(n:Int,conthumedadaire:Int):Int{
var probabilidad=conthumedadaire*100/n
    return probabilidad
}

