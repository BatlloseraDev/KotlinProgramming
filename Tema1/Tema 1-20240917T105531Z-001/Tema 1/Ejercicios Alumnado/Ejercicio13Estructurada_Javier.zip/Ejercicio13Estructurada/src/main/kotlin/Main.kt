fun main() {
    println("Dame un número: ")
    var num1 = readln().toInt()
    println("Dame otro número(Mayor que el anterior): ")
    var num2 = readln().toInt()
    var resta = 0

    var contres = 0
    while ((num1 > num2) && (num1 > 0) && (num2 > 0)) {
        resta = num1 - num2
        print("$num1 - $num2 = $resta; ")
        num1 = resta
        contres++
    }
    println("\nEl cociente es $contres y el divisor es $resta")
}