fun main() {

    var contador=0

    //hacemos do while para que ejecute primero una vez
    do {
        println("como te llamas?")
        var nombre =readln().toString()
        println("Cuantas veces quieres saludar?")
        var veces = readln().toInt()
        while(contador<veces){
            contador++
            saludar("$nombre $contador")
        }
        println("quieres volver a ejecutar el programa? \n1. Sí. \n2.No.")
        var eleccion=readln().toInt()

    }while (eleccion==1)

}

fun saludar(nombre:String){//lo que se declara aqui, es una constante, no puede cambiar

    println("Hello world! $nombre")
}