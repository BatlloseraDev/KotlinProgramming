fun main(args: Array<String>) {
    var sePuedeEjecutar = true
    while (sePuedeEjecutar) {
        var repeticiones = 0

        println("¿Como se llama la persona que quieres saludar?")
        var nombreTeclado = readln()

        println("¿Cuantas veces quieres que se repita el saludo?")
        var repeticionesMaximas = readln().toInt()

        while (repeticiones < repeticionesMaximas) {

            print(repeticiones)
            saludar(nombreTeclado)

            repeticiones++
        }

        println("¿Quieres repetir el proceso? [SI / NO]")
        var respuesta = readln()

        /*La funcion equals() con una String equivale a respuesta == "no"
        aunque esta funcion nos permite especificar si queremos que sea
        sensible a mayusculas o no y tenernos que ahorrarnos poner tres
        condiciones*/
        if (respuesta.equals("no", true))
            sePuedeEjecutar = !sePuedeEjecutar
    }

}

fun saludar(nombre:String) {
    println(" Buenas $nombre")
}
