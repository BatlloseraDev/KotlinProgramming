import kotlin.math.truncate

fun main(args: Array<String>) {
    println("Dime un numero entero.")
    var num =readln().toDouble()
    var contador=0

    while (num<=99999 && num !=0.0 ){
        num = truncate(num/10)
        contador++
    }
    println("El número de digitos es $contador")
}