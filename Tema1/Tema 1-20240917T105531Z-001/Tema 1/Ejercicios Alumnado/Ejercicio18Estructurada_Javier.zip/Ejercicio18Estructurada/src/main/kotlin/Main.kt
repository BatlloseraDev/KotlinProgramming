//JAVIER ARIAS CALERO 1ºDAW
fun main() {
    println("Vamos a simular un reloj real")
    println("Dame la hora(0-23):")
    var hora = readln().toInt()
    println("Dame el minuto(0-59):")
    var minuto = readln().toInt()
    println("Dame el segundo(0-59):")
    var segundo = readln().toInt()
    //println("Dime cuantas veces quieres ver el reloj en tiempo real:")
    //var N: Int = readln().toInt()
    var cont: Int = 0
    if ((hora <= 23) || (minuto <= 59) || (segundo <= 59)) {
        while ((hora <= 23) && (minuto <= 59) && (segundo <= 59) && (cont < 100)) {//(cont < N)
            println("Son las $hora:$minuto:$segundo")
            if (segundo >= 59) {
                minuto++
                segundo = 0
            } else {
                segundo++
            }
            if (minuto > 59) {
                hora++
                minuto = 0
                segundo = 0
            }
            if (hora > 23) {
                hora = 0
                minuto = 0
                segundo = 0
            }
            cont++
        }
    }else{
        println("Lo siento, no ha introducido bien la hora o los minutos o los segundos o los 3, inténtelo de nuevo.")
    }
}