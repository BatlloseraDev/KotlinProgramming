fun main(args: Array<String>) {
    var eleccionMaquina: Int
    var eleccionUsuario: Int
    var victoriaUsuario = 0
    var victoriaMaquina = 0


    do {
        do {
            println("Qué quieres tirar? \n1- Piedra \n2- Papel \n3- Tijera")
            eleccionUsuario = readln().toInt()
        } while (eleccionUsuario < 1 || eleccionUsuario > 3)

        eleccionMaquina = generarAleatorio()

        if (eleccionUsuario == eleccionMaquina) {
            println("EMPATE.")
        } else {
            if (esGanadorUsuario(eleccionUsuario, eleccionMaquina)) {
                victoriaUsuario++
            } else {
                victoriaMaquina++
            }
        }

        println("*******************************************************************************")
        println("Usuario: $victoriaUsuario \nMaquina: $victoriaMaquina")
        println("*******************************************************************************")

    } while (victoriaUsuario<3 && victoriaMaquina<3)

    if (victoriaUsuario == 3) {
        println("HAS GANADO!!!")
    } else {
        println("HAS PERDIDO :(")
    }

}

fun generarAleatorio(): Int {
    return (1..3).random()
}

fun esGanadorUsuario(eleccionUsuario: Int, eleccionMaquina: Int): Boolean {
    val PIEDRA = 1
    val PAPEL = 2
    val TIJERA = 3
    var victoriaUsuario = true

    if (eleccionUsuario == PIEDRA && eleccionMaquina == PAPEL) {
        println("El usuario ha sacado piedra y la máquina papel")
        victoriaUsuario = false
    } else if (eleccionUsuario == PAPEL && eleccionMaquina == PIEDRA) {
        println("El usuario ha sacado papel y la máquina piedra")
    } else if (eleccionUsuario == PIEDRA && eleccionMaquina == TIJERA) {
        println("El usuario ha sacado piedra y la máquina tijera")
    } else if (eleccionUsuario == PAPEL && eleccionMaquina == TIJERA) {
        println("El usuario ha sacado papel y la máquina tijera")
        victoriaUsuario = false
    } else if (eleccionUsuario == TIJERA && eleccionMaquina == PIEDRA) {
        println("El usuario ha sacado tijera y la máquina piedra")
        victoriaUsuario = false
    } else if (eleccionUsuario == TIJERA && eleccionMaquina == PAPEL) {
        println("El usuario ha sacado tijera y la máquina papel")
    }
    return victoriaUsuario
}