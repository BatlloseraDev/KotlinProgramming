fun main(args: Array<String>) {
    var num:Int=0
    var acu:Int=0
    var suma:Int=0
    do{
        num++
        if (num%2!=0) {
            suma=num
            acu=suma+acu
        }}
    while (num !=20)
    println(acu)
}