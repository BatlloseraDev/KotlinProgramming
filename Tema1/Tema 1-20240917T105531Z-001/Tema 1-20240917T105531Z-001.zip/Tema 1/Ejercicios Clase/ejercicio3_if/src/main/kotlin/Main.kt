fun main() {
    println( "Dame un dato")
    var dato = readln().toInt()

    if (dato%2 == 0){
        println("PAR")
    }

   /* if (!(dato == "s" || dato =="o")) {
        var dato = "8 pelocho"
        println("valor es $dato")
    }*/
    println("FIN $dato")

}