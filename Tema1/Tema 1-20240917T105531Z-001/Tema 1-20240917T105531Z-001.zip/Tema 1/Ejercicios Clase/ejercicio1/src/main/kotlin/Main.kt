fun main() {

    var DIEZ = 10


    val DIEZ1:Int=10

    DIEZ=25

    var copiaDiez:Int
    copiaDiez = DIEZ1

    copiaDiez = DIEZ + DIEZ1

//println("Suma $copiaDiez")

  //  println("Suma" + copiaDiez)

    var lolo = 'c'
    var lolo2 = "c"
    var lolo3 : Boolean = false
    var lolo33 = "false"
    var lolo4 : Int = 2
    var lolo44 : Double = 2.0

   // print(lolo + " " + lolo2 + " " + lolo3 + " " + lolo33 +" " + lolo4 +" " + lolo44)
    println(lolo + lolo4 + lolo2)
    println(lolo + lolo2 + lolo4)
}