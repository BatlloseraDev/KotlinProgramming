fun main(args: Array<String>) {
  /*  var nombre: String = "PEPE"
    println(nombre)

    nombre= "maria"
    println(nombre)*/

  /*  var div = 100
    var divisor: Int = 30

    println(div%divisor);*/


    print ("Dame el nombre:")
    var nombre :String? = readLine()
    var nombre2 = readln()


    print("\n tu nombre es $nombre $nombre2")
}