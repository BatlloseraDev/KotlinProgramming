fun main(args: Array<String>) {
   var nombreTeclado = "PEPE"
   saludar(nombreTeclado)
}

fun saludar(nombre:String){
    var nombreAux= nombre
    //nombre = "Maria"
    println("Hello World! $nombre")
}

