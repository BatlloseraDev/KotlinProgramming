fun main(args: Array<String>) {
    var cadenaOculta = pedirCadenaUsuario()
    var cadenaJugador = inicializaCadena(cadenaOculta.length)
    var intentos = 0
    var maxIntentos = 6
    var letra: Char
    var acierto = arrayOf(false)

    borrarPantalla()
    do {
        acierto[0] = false
        print("Letra: ")
        letra = readln().lowercase().get(0)
        cadenaJugador = comprobar(letra, cadenaOculta, cadenaJugador, acierto)
        if (!acierto[0]){
            intentos++
        }
        borrarPantalla()
        pintarMonigote(intentos)
        mostrarCadenaJugador(cadenaJugador)
    }while(intentos < maxIntentos && !cadenaOculta.equals(cadenaJugador))
    if (intentos == maxIntentos){
        println("Ha perdido. La cadena oculta es: ${cadenaOculta}")
    }
    else {
        println("Enhorabuena!!!")
    }
}



/**
 * Pasamos un vector con las dos cadenas, la oculta y la del jugador. Devolverá si ha habido algún acierto
 * en el vector de una posición de tipo Boolean. También devolverá de forma explícita la nueva cadena del jugador.
 */
fun comprobar(letra: Char, cadenaOculta: String, cadenaJugador: String, aci:Array<Boolean>): String {
    var cadenaDevolver : String = ""
    for (i in cadenaJugador.indices){
        if (cadenaJugador.get(i) != '_'){
            cadenaDevolver+=cadenaJugador.get(i)
        }
        else if (cadenaOculta.get(i) == letra) {
            cadenaDevolver+=letra
            aci[0] = true
        }
        else {
            cadenaDevolver+="_"
        }
    }
    return cadenaDevolver
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
/**
 * Inicializa la cadena del jugador con guiones bajos. Casillas por destapar.
 */
fun inicializaCadena(tam: Int): String {
    var cad = ""
    for (i in 1..tam){
        cad+="_"
    }
    return cad
}

/**
 * Muestra formateada la cadena del jugador.
 */
fun mostrarCadenaJugador(cad : String){
    for (i in cad.indices){
        print(" ${cad.get(i)} ")
    }
    println()
}

/**
 * Pide la cadena oculta con control de errores. Si algún carácter no es una letra la vuelve a pedir.
 * Devolverá la cadena pedida convertida en minúsculas.
 */
fun pedirCadenaUsuario():String {
    var esCorrecta = true
    var cad : String
    do {
        print("Deme una cadena para jugar al ahorcado: ")
        cad = readln().lowercase()
        esCorrecta = true
        for (i in cad.indices){
            if (!cad.get(i).isLetter()){
                esCorrecta = false
            }
        }
        if (!esCorrecta){
            println("Cadena con caracteres incorrectos. Introduzca otra.")
        }
    }while(!esCorrecta)
    return cad
}

/**
 * Función auxiliar que pinta el monigote según los intentos.
 */
fun pintarMonigote(intentos: Int) {
    println("====")
    println("   |")
    when (intentos) {
        1 -> println("   O   ")
        2 -> {
            println("   O   ")
            println("   |   ")
        }
        3 -> {
            println("   O   ")
            println(" / |   ")
        }
        4 -> {
            println("   O   ")
            println(" / | \\")
        }
        5 ->{
            println("   O   ")
            println(" / | \\")
            println("  /    ")
        }
        6 ->{
            println("   O   ")
            println(" / | \\")
            println("  / \\ ")
        }
    }
}

/**
 * Función auxiliar que limpia la pantalla.
 */
fun borrarPantalla() {
    for (i in 1..20){
        println()
    }
}