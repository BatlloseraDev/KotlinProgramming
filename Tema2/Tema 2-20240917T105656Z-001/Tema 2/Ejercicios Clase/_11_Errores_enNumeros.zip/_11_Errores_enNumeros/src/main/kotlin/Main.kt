fun main(args: Array<String>) {
    var cadena: String = "16547"
    var entero : Int = 0
    var loEs : Boolean = false


    do {
        println("Introduce un número")
        cadena = readln()
        loEs = esNumero(cadena)
        if (!loEs){
            println("Numero incorrecto")
        }
    }while (!loEs)

    println("Numero correcto")
    entero = cadena.toInt()

}


fun esNumero (cadena:String): Boolean {
    var numeros: String = "0123456789"
    //var recorrido:Int = cadena.length-1
    var esNumero: Boolean = true
    var signal: Int = 0
    var i: Int = 0

     while (i < cadena.length && esNumero == true) {
         //Opción A)
//         signal = numeros.indexOf(cadena.get(i),0,true)
//         if (signal == -1){
//             esNumero = false
//         }

         //Opción B)
         if (!cadena.get(i).isDigit())
         {
             esNumero = false
         }
         i++




//         while (i > 0) {
//             if (cadena.get(recorrido) == numeros.get(i)) {
//                 signal++
//
//             } else {
//                 esNumero = false
//             }
//             i--
//         }

//         recorrido--

     }
    return esNumero
}