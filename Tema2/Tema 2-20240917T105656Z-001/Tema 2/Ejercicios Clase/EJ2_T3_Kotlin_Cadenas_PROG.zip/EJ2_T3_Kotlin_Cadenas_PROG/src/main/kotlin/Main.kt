fun main() {
    var texto : String = ""

    print("Introduce un texto: ")
    texto = readln()

    println("${reverso(texto)}")

    texto = texto.reversed()
    println(texto)
    texto = texto.uppercase()
    println(texto)
}

fun reverso(cadena : String) : String {
    var cadOri : String = cadena
    var cadRev : String = ""
    var i : Int = cadOri.length - 1

    while(i >= 0) {
        cadRev += cadOri.get(i)
        i--
    }

    return cadRev
}