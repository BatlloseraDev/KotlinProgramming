fun main() {
    var cadOculta = ""
    var cadVisible = ""
    var intentos = 7
    var letra : Char

    println("Vamos a jugar al ahorcado, escribe un palabra.")
    cadOculta = readln().uppercase()

    if (esCadena(cadOculta)){
        cadVisible = cadenaOculta(cadOculta)
        do {
            println(cadVisible)
            println("\n" +
                    "Inserta una letra.")
            letra = readln().uppercase().get(0)
            if (esLetra(letra)){
                if (cadOculta.contains(letra)){
                    cadVisible = sustituirCad(cadOculta,cadVisible,letra)
                } else {
                    println("La letra no está en la palabra.")
                    intentos--
                }
            } else {
                println("No has introducido una letra.")
            }

        }while (intentos > 0 && cadVisible.contains('_'))
        if (intentos > 0){
            println("Has ganado.")
            println(cadVisible)
        } else {
            println("Has perdido.")
        }
    }else{
        println("No has introducido una palabra")
    }

}

fun esCadena(cad : String) : Boolean{
    var esCadena = true
    var i = 0

    while (i < cad.length-1 && esCadena){
        if (cad[i] < 'A' || cad[i] > 'Z'){
            esCadena = false
        }
        i++
    }
    return esCadena
}

fun esLetra(letra : Char) : Boolean{
    var loEs = true

    if (letra < 'A' || letra > 'Z'){
        loEs = false
    }
    return loEs
}

fun cadenaOculta(cad : String) : String{
    var aux = ""

    for (i in cad.indices){
        if (cad[i] >= 'A' || cad[i] <= 'Z'){
            aux += "_"
        }
    }
    return aux
}

fun sustituirCad(cadOculta : String, cadVisible : String, letra: Char) : String{
    var cadAux = cadVisible
    for (i in 0..cadOculta.length-1){
        if (cadOculta.get(i) == letra){
            cadAux = cadAux.replaceRange(i,i+1,letra.toString())
        }
    }
    return cadAux
}