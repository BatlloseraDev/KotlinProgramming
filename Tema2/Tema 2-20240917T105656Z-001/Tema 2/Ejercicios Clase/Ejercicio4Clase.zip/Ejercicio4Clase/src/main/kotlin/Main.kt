fun main(args: Array<String>) {
    var cad1 : String = ""
    var letra : Char = ' '

    println("Dame una palabra para la cadena: ")
    cad1 = readln()
    print("Dame la letra a buscar: ")
    letra = readln().get(0)

    println("En la palabra '${cad1}' hay ${cuantasApariciones(cad1, letra)} apariciones")
}


fun cuantasApariciones(cad1 : String, l : Char):Int{
    var cont = 0
    var cadAux = cad1.uppercase()

    for(i in cad1.indices) {
        if (cadAux.get(i) == l.uppercase().get(0)){
            cont++
        }
    }
    return cont
}