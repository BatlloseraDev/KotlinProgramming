fun main() {
    val cad:String
    val car:Char

    println("Introduce una cadena de texto")
    cad= readln()
    println("Introduce el carácter")
    car= readln()[0]

    println("El caracter aparece ${contarVeces(cad,car)} en la palabra")
}

fun contarVeces(cad:String,car:Char):Int{
    var cont=0
    var inic=0

    while(inic!=-1){
        inic=cad.indexOf(car,inic,true)

        if(inic!=-1){
            cont++
            inic++
        }
    }

    return cont
}

fun contarPalabras(cadOriginal:String):Int{
    var cont=0
    var inic=0
    var cad = cadOriginal.trim()

    while(inic!=-1){
        inic=cad.indexOf(' ',inic,true)

        if(inic!=-1){
            cont++
            inic++
        }
    }

    return cont+1
}

