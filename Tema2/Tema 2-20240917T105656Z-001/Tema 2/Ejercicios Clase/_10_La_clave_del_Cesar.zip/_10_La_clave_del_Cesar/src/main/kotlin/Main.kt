fun main(args: Array<String>) {
    var texto: String = ""
    var letra: Char = ' '
    var textoCifrado: String = ""


    println("Escriba la frase que quiera cifrar")
    texto = readln().uppercase()

    for (i in 0..texto.length-1){
        letra = texto.get(i) + 1
        textoCifrado = textoCifrado + letra
    }


//    textoCifrado = textoCifrado.replace('!',' ',true)
    textoCifrado = textoCifrado.replace('[','A',true)
    textoCifrado = textoCifrado.replace(':', '0', true)

    println(textoCifrado)

}
