fun main() {
   var cad = ""

   println("Escribe una cadena: ")
   cad = readln()

   println(cad.reversed().toUpperCase() )
}