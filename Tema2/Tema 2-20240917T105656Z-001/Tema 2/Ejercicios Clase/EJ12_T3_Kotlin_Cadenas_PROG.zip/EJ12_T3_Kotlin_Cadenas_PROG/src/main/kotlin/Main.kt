fun main() {
    var palabra : String = ""
    lateinit var advPalabra : Array<Char>
    var letra : Char = ' '
    var intentos : Int = 0
    var esValido : Boolean = false
    var existe : Boolean = false
    var haGanado : Boolean = false

    do {
        print("Palabra: ")
        palabra = readln()
        esValido = tieneSoloLetras(palabra)
    } while(!esValido)

    advPalabra = inicializarTableroJug(palabra)

    for(i in 1..30) {
        println() //"Borrar" la pantalla
    }

   do {
       print("\nLetra (${intentos}/7 intentos): ")
       letra = readln().get(0)

       for(i in palabra.indices) {
           if(palabra.get(i) == letra) {
               existe = true
               advPalabra[i] = letra
           }
       }

       if(!existe) {
           intentos++
       }

       mostrarTablero(advPalabra)

       existe = false
       haGanado = sonIguales(advPalabra, palabra)

   } while(!haGanado && intentos <= 7)

   if(haGanado) {
       println("\n¡Correcto!")
   } else {
       println("\nRespuesta: $palabra")
   }
}

fun tieneSoloLetras(texto : String) : Boolean {
    var loEs : Boolean = true
    var i : Int = 0

    while(i < texto.length - 1 && loEs) {
        if(!texto.get(i).isLetter()) {
            loEs = false
        }
        i++
    }
    return loEs
}

fun inicializarTableroJug(texto : String) : Array<Char> = Array<Char>(texto.length){'_'}

fun mostrarTablero(tablero : Array<Char>) {
    for(i in tablero.indices) {
        if(tablero.get(i) == '_') {
            print(" _ ")
        } else {
            print(" ${tablero.get(i)} ")
        }
    }
}

fun sonIguales(tablero : Array<Char>, texto : String) : Boolean {
    var res : String = ""
    var loSon : Boolean = false

    for(i in texto.indices) {
        res += tablero[i]
    }

    if(res == texto) {
        loSon = true
    }

    return loSon
}