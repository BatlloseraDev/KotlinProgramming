fun main() {
    var texto : String = ""
    var vocales : Array<Char> = arrayOf('a', 'e', 'i', 'o', 'u')
    var numvoc : Int = 0

    print("Texto: ")
    texto = readln()

    for(i in texto.indices) {
        for(j in vocales.indices) {
            if(texto.lowercase().get(i) == vocales[j]) {
                numvoc++
            }
        }
    }
    println("El texto tiene ${numvoc} vocal/es")
}