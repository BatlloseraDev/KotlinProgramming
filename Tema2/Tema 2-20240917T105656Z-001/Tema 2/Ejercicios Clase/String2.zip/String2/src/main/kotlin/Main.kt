fun main(){
    var cad: String?

    println("Introduce una cadena: ")
    cad = readln()

    println("La cadena invertida es ${cad.reversed()}")
    println("Y en mayúsculas es ${cad.reversed().uppercase()}")
    println(cad)

}

