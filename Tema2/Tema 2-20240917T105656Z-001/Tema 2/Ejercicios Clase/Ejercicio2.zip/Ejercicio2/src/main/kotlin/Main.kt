fun main(args: Array<String>) {
    var cad1 : String = ""

    println("Dame un nombre que lo invierto: ")
    cad1= readln()

    println(cad1.reversed().uppercase())
}