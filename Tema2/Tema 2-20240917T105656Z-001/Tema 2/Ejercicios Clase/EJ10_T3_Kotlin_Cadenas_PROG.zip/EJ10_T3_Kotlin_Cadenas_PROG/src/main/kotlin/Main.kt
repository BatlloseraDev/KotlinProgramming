fun main() {
    var mensaje : String = ""
    var encriptado : String = ""

    var numDec : Array<Char> = arrayOf('0', '1', '2', '3', '4', '5', '6', '7', '8', '9')
    var alfabeto : Array<Char> = arrayOf('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N',
        'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z') //Basado en el alfabeto ingles

    print("Mensaje: ")
    mensaje = readln().uppercase()

    for(i in mensaje.indices) {

        for(j in numDec.indices) {
            if(mensaje.get(i) == numDec[j]) {
                if(mensaje.get(i) != '9') {
                    encriptado += (mensaje.get(i).toInt() + 1).toChar()
                } else {
                    encriptado += '0'
                }
            }
        }

        for(j in alfabeto.indices) {
            if(mensaje.get(i) == alfabeto[j]) {
                if(mensaje.get(i) != 'Z') {
                    encriptado += (mensaje.get(i).toInt() + 1).toChar()
                } else {
                    encriptado += 'A'
                }
            }
        }

    }

    println("Mensaje encriptado: $encriptado")
}