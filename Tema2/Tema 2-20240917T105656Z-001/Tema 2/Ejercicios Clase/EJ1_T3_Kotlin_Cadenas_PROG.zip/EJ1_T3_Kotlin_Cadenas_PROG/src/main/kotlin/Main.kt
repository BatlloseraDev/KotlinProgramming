fun main() {
    var cad1 : String = ""
    var cad2 : String = ""

    print("Primera cadena: ")
    cad1 = readln()
    print("Segunda cadena: ")
    cad2 = readln()

    if(cad1.length == cad2.length) {
        println("La longitud es igual (${cad1.length} caracter/es)")
    } else {
        println("La longitud es diferente:")
        println("\tCadena 1: ${cad1.length} caracter/es")
        println("\tCadena 2: ${cad2.length} caracter/es")
    }

    if(cad1.compareTo(cad2) > 0) {
        println("\"${cad1}\" es mayor que \"${cad2}\"")
    } else if(cad1.compareTo(cad2) < 0) {
        println("\"${cad1}\" es menor que \"${cad2}\"")
    } else {
        println("Ambos son iguales")
    }
}