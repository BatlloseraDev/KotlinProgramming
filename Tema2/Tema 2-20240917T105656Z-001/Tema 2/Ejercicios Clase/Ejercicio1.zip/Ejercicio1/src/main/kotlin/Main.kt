fun main(args: Array<String>) {
    var cad1 : String = ""
    var cad2 : String = ""

    println("Dame la primera cadena: ")
    cad1 = readln()
    println("Dame la segunda cadena: ")
    cad2 = readln()

    if (cad1.length == cad2.length){
        println("Tienen la misma longitud de caracteres: ${cad1.length} ")
    }else{
        println("No tienen la misma longitud")
    }

    if (cad1 == cad2) {
       println("Cadena1 y cadena2 son iguales");
    } else {
        println("Cadena1 y cadena2 son distintas");
    }
}