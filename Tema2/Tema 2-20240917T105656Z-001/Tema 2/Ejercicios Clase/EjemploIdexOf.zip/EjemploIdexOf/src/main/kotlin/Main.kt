fun main(args: Array<String>) {
    var cad = "lo que seua"
    println(cad.indexOf('Z',0,true))

}