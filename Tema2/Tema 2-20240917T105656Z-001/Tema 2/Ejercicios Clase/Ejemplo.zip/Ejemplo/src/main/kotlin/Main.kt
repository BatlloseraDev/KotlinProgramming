fun main(args: Array<String>) {
    var cad : String = "  ab56cd "
    var n = 0
    var cad3 = cad.toCharArray()
    cad = cad3.toString()





    println(cad3[0])
    var nombre = "Ramón"
    var listado = Array<String>(27){""}

    cad = readln()
    cad = cad.trim()
    var cuantasCifras = cad.length
    n = cad.toInt()
    n++

    println("Has introducido el ${n} con ${cuantasCifras} cifras")


    if (cad.isEmpty()){
        println("Esta vacía")
    }
    else {
        println("Pues no")
    }
    println(cad.length)
    println(cad.uppercase())
    cad = cad.uppercase()
    println(cad)
    println(cad.length)

    for (i in cad.indices){
        if (cad.get(i) == ' '){
            println()
        }
        println(cad.get(i))
    }
}

fun laQueSea(cad : String){
    cad = cad.uppercase()
}