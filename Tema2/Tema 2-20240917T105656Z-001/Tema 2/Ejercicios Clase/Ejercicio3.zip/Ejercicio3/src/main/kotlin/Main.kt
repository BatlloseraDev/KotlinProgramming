fun main(args: Array<String>) {
    var cad1 : String = ""

    println("Dame una palabra para la cadena: ")
    cad1 = readln()

    println("En la palabra ${cad1} hay ${cuantasVocales(cad1)} vocales")
}


fun cuantasVocales(cad1 : String):Int{
    var cont = 0
    var cadAux = cad1.uppercase()

    for(i in cad1.indices) {
        if (cadAux.get(i) == 'A' || cadAux.get(i) == 'E'|| cadAux.get(i) == 'I' || cadAux.get(i) == 'O' || cadAux.get(i) == 'U'){
            cont++
        }
    }
    return cont
}