import herencia.*


fun main(args: Array<String>) {
   var p= Persona ("PEPE",22, 1.7)
    p.saludar()

    var e= Enfermera("Matrona","VdG","Maria",23,1.8)
    e.saludar()
}