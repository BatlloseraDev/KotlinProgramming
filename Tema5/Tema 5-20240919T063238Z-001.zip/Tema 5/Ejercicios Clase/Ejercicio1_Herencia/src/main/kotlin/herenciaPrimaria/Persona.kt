package herenciaPrimaria

open class Persona(nombre:String,edad:Int,altura:Double) {
    fun saludar(){
        println("Soy una persona")
    }
}