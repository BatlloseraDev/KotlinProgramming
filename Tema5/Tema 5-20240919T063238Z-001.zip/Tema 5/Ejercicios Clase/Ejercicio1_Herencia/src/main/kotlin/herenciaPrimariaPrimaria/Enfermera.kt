package herenciaPrimariaPrimaria

class Enfermera(especialidad:String,hospital:String,nombre:String,edad:Int,altura:Double):Persona(nombre,edad,altura) {
}