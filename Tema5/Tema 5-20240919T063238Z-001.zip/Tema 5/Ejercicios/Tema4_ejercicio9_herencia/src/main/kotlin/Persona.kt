class Persona {
    var dni: Int =0
    var nombre: String=""
    var edad:Int=0
}