enum class Tipo {
    Arma,
    Medicina,
    Trampa;
}