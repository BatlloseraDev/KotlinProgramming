class Mecanico:Persona {
    constructor(nombre:String,x:Int,y:Int) : super(nombre,x,y) {
    }


}