class Supervisora:Persona {
    constructor(nombre:String,x:Int,y:Int) : super(nombre,x,y) {
    }
}