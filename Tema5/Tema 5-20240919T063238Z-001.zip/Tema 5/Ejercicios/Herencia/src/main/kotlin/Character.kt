open class Character(val name: String) {
    open fun die() = println("Morir")
}
