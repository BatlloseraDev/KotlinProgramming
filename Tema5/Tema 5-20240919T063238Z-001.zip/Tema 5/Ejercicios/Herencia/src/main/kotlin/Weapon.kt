open class Weapon(val damage: Int, val speed: Double){
}