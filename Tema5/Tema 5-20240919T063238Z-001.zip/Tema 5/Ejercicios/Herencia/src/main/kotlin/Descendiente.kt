class Descendiente(propiedad: Boolean) : Ancestro(propiedad){
}