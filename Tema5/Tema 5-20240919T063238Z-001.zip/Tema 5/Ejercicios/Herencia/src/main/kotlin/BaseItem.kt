open class BaseItem(val name: String) {
    open var quantity = 1
    var dato = 2
}
