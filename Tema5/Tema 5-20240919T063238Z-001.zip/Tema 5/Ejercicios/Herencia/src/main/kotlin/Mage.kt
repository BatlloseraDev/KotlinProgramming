class Mage(name: String) : Character(name) {
    override fun die() = println("Mago muriendo")
}
