class PopularItem(name: String) : BaseItem(name) {
    override var quantity = 6
    //override var dato = 7  no se puede sobrescribir pues no es open
}
