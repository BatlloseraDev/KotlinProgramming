class Bow : Weapon {
    constructor(damage: Int, speed: Double) : super(damage, speed)
}
