open class Ancestro (val propiedad:Boolean){
}


