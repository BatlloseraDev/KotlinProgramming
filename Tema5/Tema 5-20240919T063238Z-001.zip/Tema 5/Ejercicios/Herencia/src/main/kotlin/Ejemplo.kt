class Ejemplo {
}