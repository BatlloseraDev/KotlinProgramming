open class Animal {
    open fun makeSound() {
        println("El animal hace un sonido")
    }
}
