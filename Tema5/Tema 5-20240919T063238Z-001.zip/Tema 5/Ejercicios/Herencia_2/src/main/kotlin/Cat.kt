final class Cat: Animal() {
    override fun makeSound() {
        println("El gato maulla")
    }
}
