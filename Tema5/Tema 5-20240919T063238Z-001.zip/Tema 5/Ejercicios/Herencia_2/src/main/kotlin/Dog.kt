open class Dog: Animal() {
    override fun makeSound() {
        println("El perro ladra")
    }
}
