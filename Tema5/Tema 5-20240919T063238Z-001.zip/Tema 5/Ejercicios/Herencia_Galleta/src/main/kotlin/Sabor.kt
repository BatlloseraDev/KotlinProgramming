class Sabor {
    var gradoDulzura=0
    var coste = 0
    var nombre=""
}