class Elemento {
    var nombre:String = ""
    var carbohidratos = 0
    var grasas:Int=0
    var porcentaje: Int=0

}