class Forma {
    var tiempoModelado: Int = 0
    var dificultad: Int = 0

}