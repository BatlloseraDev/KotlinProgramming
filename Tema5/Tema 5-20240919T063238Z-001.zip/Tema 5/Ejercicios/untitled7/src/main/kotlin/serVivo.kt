interface serVivo {
    fun nace()
    fun crece()
    fun muere()
}