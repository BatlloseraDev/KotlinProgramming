class Rosa: Vegetal(), serVivo {
    override var vivo:Boolean = true

    override fun estaVivo(valor: Int, tipo:String){}

    override fun nace() {

    }

    override fun crece() {

    }

    override fun muere() {

    }
}