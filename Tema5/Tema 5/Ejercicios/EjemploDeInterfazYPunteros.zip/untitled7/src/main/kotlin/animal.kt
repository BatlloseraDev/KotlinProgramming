interface animal {
    var vivo: Boolean

    fun estaVivo(valor: Int):Boolean

}