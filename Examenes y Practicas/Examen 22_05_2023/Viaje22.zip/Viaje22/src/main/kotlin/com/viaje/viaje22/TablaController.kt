package com.viaje.viaje22

import Servivio.VistaViajeServicio
import javafx.beans.property.SimpleBooleanProperty
import javafx.beans.property.SimpleObjectProperty
import javafx.beans.property.SimpleStringProperty
import javafx.collections.FXCollections
import javafx.collections.ObservableList
import javafx.fxml.FXML
import javafx.fxml.Initializable
import javafx.scene.control.Button
import javafx.scene.control.Label
import javafx.scene.control.TableColumn
import javafx.scene.control.TableView
import javafx.stage.Stage
import java.io.IOException
import java.net.URL
import java.time.ZoneId
import java.util.*

class TablaController:Initializable {
    @FXML
    private lateinit var btnSalir: Button
    @FXML
    private lateinit var  colUsuario: TableColumn<VistaViaje, String>
    @FXML
    private lateinit var colDestino: TableColumn<VistaViaje, String>
    @FXML
    private lateinit var  colFecha: TableColumn<VistaViaje, Date>
    @FXML
    private lateinit var colPagado: TableColumn<VistaViaje, Boolean>

    @FXML
    private lateinit var tablaViaje: TableView<VistaViaje>

    //private lateinit var btnEliminar: Button

    private lateinit var obLista: ObservableList<VistaViaje>
    private val vistaviaje = VistaViajeServicio()

    override fun initialize(p0: URL?, p1: ResourceBundle?) {

        colUsuario.setCellValueFactory { cellData ->
            SimpleStringProperty(cellData.value.usuario)
        }
        colDestino.setCellValueFactory { cellData ->
            SimpleStringProperty(cellData.value.destino)
        }

        colPagado.setCellValueFactory { cellData ->
            SimpleBooleanProperty(cellData.value.pagado)
        }

        colFecha.setCellValueFactory {
                cellData->
            val fechaNacimiento = cellData.value.fecha
            val fechaNacimientoSql =
                java.sql.Date.from(fechaNacimiento.atStartOfDay(ZoneId.systemDefault()).toInstant())
            SimpleObjectProperty(fechaNacimientoSql)
        }

        obLista = FXCollections.observableArrayList()
        for (i in vistaviaje.seleccionarAlumnos()){
            obLista.add(i)
        }
        tablaViaje.items=obLista //el items de la tabla es el que necesita la conversion de String --> SimpleStringProperty para poder representarlos internamente
    }
    @FXML
    private fun cerrar() {
        try {
            //persona.nombre = "Cambio"
            val stage = btnSalir.scene.window as Stage
            stage.close()
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }

}