package com.viaje.viaje22

import java.io.Serializable

class Usuario:Serializable {
    var id:Int=0
    var nombre:String=""
    var fecha:String=""

    constructor(i:Int, n:String, f:String){
        id=i
        nombre=n
        fecha=f
    }
    override fun toString(): String {
        return "$id - $nombre"
    }
}