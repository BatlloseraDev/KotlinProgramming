package com.viaje.viaje22

import java.time.LocalDate

class VistaViaje {
    var usuario:String=""
    var destino:String=""
    var fecha= LocalDate.now()
    var pagado:Boolean=false

    constructor(usuario: String, destino: String, fecha: LocalDate?, pagado: Boolean) {
        this.usuario = usuario
        this.destino = destino
        this.fecha = fecha
        this.pagado = pagado
    }

    override fun toString(): String {
        return "VistaViaje(usuario='$usuario', destino='$destino', fecha=$fecha, pagado=$pagado)"
    }
}