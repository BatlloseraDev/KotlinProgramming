package com.viaje.viaje22

import Servivio.ServicioCiudades
import Servivio.ServicioUsuario
import javafx.fxml.FXML
import javafx.fxml.FXMLLoader
import javafx.scene.Parent
import javafx.scene.Scene
import javafx.scene.control.Alert
import javafx.scene.control.ButtonType
import javafx.scene.control.Label
import javafx.scene.control.TextInputDialog
import javafx.stage.FileChooser
import javafx.stage.Modality
import javafx.stage.Stage
import java.io.File

class InicioController {
    @FXML
    private lateinit var lblNombre: Label

    val ser = ServicioUsuario()
    val ciu = ServicioCiudades()
    var destino = Destinos()

    @FXML
    private fun CrearFichero() {
        val dialog = TextInputDialog()
        dialog.title = "Fichero"
        dialog.headerText = null
        dialog.contentText = "Nombre:"
        val result = dialog.showAndWait()
        var nombre = Constantes.FicheroUsuario
        if (result.isPresent) {
            nombre = result.get()
        }
        ser.CrearFichero(nombre)
    }
    @FXML
    private fun GuardarBBDD() {
        ser.LeerFichero()
        val infoAlert = Alert(Alert.AlertType.INFORMATION)
        infoAlert.title = "Información"
        infoAlert.headerText = "ACTUALIZACIÓN BASE DE DATOS"
        infoAlert.contentText = "Usuarios guardados"
        infoAlert.showAndWait()
    }
    @FXML
    private fun InsertarBBDDCiudades() {
       ciu.leerInsertarBBDD()
    }
    @FXML
    private fun CrearFicheroCiudades() {
        ciu.bbddFichero()
    }

    @FXML
    private fun abrirTabla() {
        val loader = FXMLLoader(javaClass.getResource("tabla-view.fxml"))
        val root = loader.load<Parent>()
        val stage = Stage()
        stage.scene = Scene(root)
        stage.initModality(Modality.APPLICATION_MODAL)
        stage.showAndWait()

    }


    @FXML
    private fun NuevoDestino() {
        val loader = FXMLLoader(javaClass.getResource("alta-view.fxml"))
        val root = loader.load<Parent>()
        val detailController = loader.getController<AltaController>()

        //estos dos métodos estan separados para que se entiendan mejor,
        // se podrian realizar en uno solamente
        //var pp = Persona("yo")
        detailController.transpaso(this.destino)
        val stage = Stage()
        stage.scene = Scene(root)
        stage.initModality(Modality.APPLICATION_MODAL)
        stage.showAndWait()
        lblNombre.text = destino.nombre
    }
}