package com.viaje.viaje22

class Ciudades {
    var id:Int=0
    var nombre:String=""

    constructor(n:String){
        nombre=n

    }
    constructor(i:Int, n:String){
        id=i
        nombre=n

    }

    override fun toString(): String {
        return "Ciudades(id=$id, nombre='$nombre')"
    }

}