package com.viaje.viaje22

class Constantes {
    companion object{

        val url="jdbc:mysql://localhost/viajes22"
        val user="root"
        val password=""
        val forname="com.mysql.cj.jdbc.Driver"

        ///Ficheros
        val FicheroUsuario="Usuarios.txt"
        val FicheroCiudad="ciudades.txt"
        val FicheroCiudad2="ciudades2.txt"
        val mensajeFicheros="Error en Fichero"

        ///Tabla Usuario
        val usuarioSql1="SELECT id,nombre,DATE_FORMAT(fecha_nacimiento, '%d/%m/%Y') AS fecha_nacimiento_string FROM Usuario"
        val usuarioSql2 = "INSERT INTO usuario (nombre,fecha_nacimiento) VALUES (?,STR_TO_DATE(?, '%d/%m/%Y'));"

        val ciudadSql1 = "INSERT INTO ciudades (ciudad) VALUES (?);"
        val ciudadSql2 = "SELECT id,ciudad from ciudades;"

        val destinosSql1 = "SELECT id,nombre from destinos;"

        val vistaViajesql1="select usuario.nombre,destinos.nombre,fecha_viaje,pagado from viaje inner join destinos on id_destino = destinos.id inner join usuario on id_usuario=usuario.id order by fecha_viaje;"

    }
}