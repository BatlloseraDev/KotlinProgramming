package BBDD

import com.viaje.viaje22.VistaViaje

interface VistaViajeDAO {
    fun seleccionarVistaViaje(): List<VistaViaje>
}