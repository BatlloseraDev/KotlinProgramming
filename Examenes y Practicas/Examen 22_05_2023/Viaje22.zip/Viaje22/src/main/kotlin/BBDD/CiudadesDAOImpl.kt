package BBDD

import com.viaje.viaje22.Ciudades
import com.viaje.viaje22.Constantes
import com.viaje.viaje22.Usuario
import java.sql.PreparedStatement

class CiudadesDAOImpl:CiudadesDAO {
    private val conexion= ConexionBD()
    override  fun insertarCiudad(usu:List<Ciudades>){
        conexion.conectar()
        var result:Int?=null
        var ps: PreparedStatement? = null

        for(a in usu) {
            val query = Constantes.ciudadSql1
            ps = conexion.getPreparedStatement(query)
            try {
                ps?.setString(1, a.nombre)
                result = ps?.executeUpdate()
            } catch (e: Exception) {
                println("No Se puede insertar ${a.nombre}")
            }
        }
        ps?.close()
        conexion.desconectar()
    }

    override fun seleccionarCiudades(): List<Ciudades>{
        conexion.conectar()
        val query = Constantes.ciudadSql2
        val st = conexion.getStatement()
        val rs = st?.executeQuery(query)
        val lista = ArrayList<Ciudades>()
        while (rs?.next() == true) {
            val ciu = Ciudades(rs.getInt("id"),rs.getString("ciudad"))
            lista.add(ciu)
        }
        st?.close()
        conexion.desconectar()
        return lista
    }
}