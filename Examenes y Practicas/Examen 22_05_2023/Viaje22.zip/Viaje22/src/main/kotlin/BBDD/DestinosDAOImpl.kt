package BBDD


import com.viaje.viaje22.Constantes
import com.viaje.viaje22.Destinos

class DestinosDAOImpl:DestinosDAO {
    private val conexion= ConexionBD()
    override fun seleccionarDestino(): List<Destinos>{
        conexion.conectar()
        val query = Constantes.destinosSql1
        val st = conexion.getStatement()
        val rs = st?.executeQuery(query)
        val lista = ArrayList<Destinos>()
        while (rs?.next() == true) {
            val des = Destinos(rs.getInt("id"),rs.getString("nombre"))
            lista.add(des)
        }
        st?.close()
        conexion.desconectar()
        return lista
    }
}