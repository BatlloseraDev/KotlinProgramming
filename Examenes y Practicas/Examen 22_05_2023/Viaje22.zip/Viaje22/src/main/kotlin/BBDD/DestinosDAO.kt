package BBDD

import com.viaje.viaje22.Destinos

interface DestinosDAO {
    fun seleccionarDestino(): List<Destinos>
}