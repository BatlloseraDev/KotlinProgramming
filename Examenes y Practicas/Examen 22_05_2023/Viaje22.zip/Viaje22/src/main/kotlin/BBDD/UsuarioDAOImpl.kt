package BBDD

import com.viaje.viaje22.Constantes
import com.viaje.viaje22.Usuario
import java.sql.Connection
import java.sql.PreparedStatement

class UsuarioDAOImpl:UsuarioDAO {
    private val conexion= ConexionBD()

    override fun seleccionarUsuario(): List<Usuario>{
        conexion.conectar()
       val query = Constantes.usuarioSql1
        val st = conexion.getStatement()
        val rs = st?.executeQuery(query)
        val lista = ArrayList<Usuario>()
        while (rs?.next() == true) {
            val usu = Usuario(rs.getInt("id"),rs.getString("nombre"),rs.getString("fecha_nacimiento_string"))
            lista.add(usu)
        }
        st?.close()
        conexion.desconectar()
        return lista
    }

    override fun insertarUsuario(usu:List<Usuario>) {
        conexion.conectar()
        var result:Int?=null
        var ps: PreparedStatement? = null

        for(a in usu) {
            val query = Constantes.usuarioSql2
            ps = conexion.getPreparedStatement(query)
            try {
                ps?.setString(1, a.nombre)
                ps?.setString(2, a.fecha)
                result = ps?.executeUpdate()
            } catch (e: Exception) {
                println("No Se puede insertar ${a.nombre}")
            }
        }
        ps?.close()
        conexion.desconectar()
    }
}