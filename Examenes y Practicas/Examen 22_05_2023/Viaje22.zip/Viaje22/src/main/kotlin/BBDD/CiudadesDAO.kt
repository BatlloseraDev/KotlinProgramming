package BBDD

import com.viaje.viaje22.Ciudades

interface CiudadesDAO {
    fun insertarCiudad(usu:List<Ciudades>)
    fun seleccionarCiudades(): List<Ciudades>
}