package BBDD

import com.viaje.viaje22.Usuario

interface UsuarioDAO {
    fun seleccionarUsuario(): List<Usuario>
    fun insertarUsuario(a:List<Usuario>)
}