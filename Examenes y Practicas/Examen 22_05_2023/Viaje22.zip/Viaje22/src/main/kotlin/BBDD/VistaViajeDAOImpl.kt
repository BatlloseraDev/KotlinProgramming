package BBDD

import com.viaje.viaje22.Ciudades
import com.viaje.viaje22.Constantes
import com.viaje.viaje22.VistaViaje

class VistaViajeDAOImpl:VistaViajeDAO {
    private val conexion= ConexionBD()
    override fun seleccionarVistaViaje(): List<VistaViaje>{
        conexion.conectar()
        val query = Constantes.vistaViajesql1
        val st = conexion.getStatement()
        val rs = st?.executeQuery(query)
        val lista = ArrayList<VistaViaje>()
        while (rs?.next() == true) {
            val via = VistaViaje(rs.getString("usuario.nombre"),rs.getString("destinos.nombre"),(rs.getDate("fecha_viaje")).toLocalDate(),rs.getBoolean("pagado"))
            lista.add(via)
        }
        st?.close()
        conexion.desconectar()
        return lista
    }
}