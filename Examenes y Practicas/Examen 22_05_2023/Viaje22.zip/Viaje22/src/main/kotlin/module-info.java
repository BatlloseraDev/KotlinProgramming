module com.viaje.viaje22 {
    requires javafx.controls;
    requires javafx.fxml;
    requires kotlin.stdlib;
    requires java.sql;


    opens com.viaje.viaje22 to javafx.fxml;
    exports com.viaje.viaje22;
}