package Servivio

import BBDD.UsuarioDAOImpl
import Fichero.*
import com.viaje.viaje22.Constantes
import com.viaje.viaje22.Usuario

class ServicioUsuario {
    var usuarioBD = UsuarioDAOImpl()

    fun CrearFichero(s:String){
        UsuarioSerializable.insertar(s,usuarioBD.seleccionarUsuario())
    }

    fun LeerFichero(){
        usuarioBD.insertarUsuario(UsuarioSerializable.leer(Constantes.FicheroUsuario))
    }

    fun devolverUsuarios():List<Usuario>{
        return usuarioBD.seleccionarUsuario()
    }
}