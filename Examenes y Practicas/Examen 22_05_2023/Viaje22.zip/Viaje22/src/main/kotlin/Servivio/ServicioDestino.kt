package Servivio

import BBDD.DestinosDAOImpl

import com.viaje.viaje22.Destinos


class ServicioDestino {

    var destinoBD = DestinosDAOImpl()

    fun devolverDestinos():List<Destinos>{
        return destinoBD.seleccionarDestino()
    }
}