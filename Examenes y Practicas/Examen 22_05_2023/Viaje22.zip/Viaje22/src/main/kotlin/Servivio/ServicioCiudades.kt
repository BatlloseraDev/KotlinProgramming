package Servivio

import BBDD.CiudadesDAOImpl
import BBDD.UsuarioDAOImpl
import Fichero.CiudadesFichero
import com.viaje.viaje22.Constantes

class ServicioCiudades {
    var ciudadBD = CiudadesDAOImpl()
    fun leerInsertarBBDD(){
        ciudadBD.insertarCiudad(CiudadesFichero.leer(Constantes.FicheroCiudad))
    }

    fun bbddFichero(){
        CiudadesFichero.escribir(Constantes.FicheroCiudad2,ciudadBD.seleccionarCiudades())
    }
}