package Servivio

import BBDD.VistaViajeDAOImpl
import com.viaje.viaje22.VistaViaje


class VistaViajeServicio {
    private val vistaDAO= VistaViajeDAOImpl()

    fun seleccionarAlumnos(): List<VistaViaje> {
        return vistaDAO.seleccionarVistaViaje()
    }

}