package Fichero

import com.viaje.viaje22.Constantes
import com.viaje.viaje22.Usuario
import java.io.*

class UsuarioSerializable {
    companion object {
        fun insertar(n: String, a: List<Usuario>) {
            var os: ObjectOutputStream? = null
            try {
                var fs = FileOutputStream(n);//Creamos el archivo
                os = ObjectOutputStream(fs);//Esta clase tiene el método writeObject() que necesitamos
                for (i in a) {
                    os.writeObject(i);//El método writeObject() serializa el objeto y lo escribe en el archivo
                }
            } catch (e: FileNotFoundException) {
                e.printStackTrace();
            } catch (e: IOException) {
                e.printStackTrace();
            } finally {
                os?.close();//Hay que cerrar siempre el archivo
            }
        }
        fun leer(n: String):List<Usuario> {

            val lista = ArrayList<Usuario>()
            var fis: FileInputStream? = null
            var ois: ObjectInputStream? = null

            try {
                fis = FileInputStream(n)
                ois = ObjectInputStream(fis)
                while (true) {
                    var a1 = ois.readObject()
                    lista.add(a1 as Usuario)
                    print(a1)
                }
            } catch (e: FileNotFoundException) {
                e.printStackTrace()
            } catch (e: EOFException) {
                println(Constantes.mensajeFicheros)
                // Se captura la excepción EOFException al llegar al final del archivo
            }catch (e: IOException) {
                e.printStackTrace()
            } catch (e: ClassNotFoundException) {
                e.printStackTrace()
            }  finally {
                ois?.close()
                fis?.close()
                ois?.close()
                return lista
            }
        }
    }
}