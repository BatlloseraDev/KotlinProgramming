package Fichero

import com.viaje.viaje22.Ciudades
import com.viaje.viaje22.Usuario
import java.io.File
import java.io.FileWriter
import java.io.PrintWriter

class CiudadesFichero {
    companion object {
        fun leer(fichero: String): List<Ciudades> {
            val lista = ArrayList<Ciudades>()
            val file = File(fichero)
            // Leer el archivo línea por línea utilizando readLines
            val lineas = file.readLines()
            for (linea in lineas) {
                lista.add(Ciudades(linea))
                println(linea)
            }
            return lista
        }
        fun escribir(fichero:String, ciu:List<Ciudades>){
            try {
                val ruta = fichero
                val fw = FileWriter(ruta, false)
                // fw.write("soy escrito con el método write")
                // fw.write("\n")
                val salida = PrintWriter(fw)
                for(a in ciu) {
                    salida.println(a.nombre)
                }
                salida.flush() //asegurarnos que todos los datos se escriben antes de cerrar el flujo de escritura
                salida.close()
            } catch (e: Exception) {
                println(e.message)
            }
        }
    }
}