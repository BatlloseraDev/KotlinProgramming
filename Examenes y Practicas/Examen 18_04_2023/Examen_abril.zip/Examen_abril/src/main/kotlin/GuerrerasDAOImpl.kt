import java.sql.PreparedStatement

class GuerrerasDAOImpl:GuerrerasDAO {
    companion object{
        var cantidadGuerreras= 1
    }
    private val conexion = ConexionBD()
    override fun xGuerreras(numero:Int): List<Guerreras>{
        conexion.conectar()
        val ejercito = ArrayList<Guerreras>()
        //val query2 = "SELECT * FROM GUERRERAS WHERE id BETWEEN ? AND ? "
        val query = Constantes.SQL
        var ps = conexion.getPreparedStatement(query)
        try {
            ps?.setInt(1, cantidadGuerreras)
            cantidadGuerreras=cantidadGuerreras+numero+1
            ps?.setInt(2, cantidadGuerreras)
            cantidadGuerreras ++
            var rs = ps?.executeQuery()

            while (rs?.next() == true) {
                val e = Guerreras(rs.getInt(Constantes.esperanzadevida),rs.getInt(Constantes.edad), rs.getString(Constantes.nombre),rs.getInt(Constantes.indice_inteligencia),rs.getInt(Constantes.fuerza))
                ejercito.add(e)
            }
        }catch (e:Exception) {

        }
        ps?.close()
        conexion.desconectar()
        return ejercito
    }
}

