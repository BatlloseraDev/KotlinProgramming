class Constantes {
    companion object{
        var Fuerza:Int=1
        var PuedoRealizarTarea:Int=1
        var noPuedoRealizarTarea:Int=0

        var Joven: Int = 0
        var Mayor: Int = 1
        var Muerto: Int = 2

        var Libre: Int =0
        var noLibre: Int =1


        val url="jdbc:mysql://localhost/examen2"
        val user="root"
        val password=""
        val forname="com.mysql.cj.jdbc.Driver"

        val SQL= "SELECT * FROM GUERRERAS WHERE id BETWEEN ? AND ? "
        val esperanzadevida = "esperanzadevida"
        val edad = "edad"
        val nombre = "nombre"
        val indice_inteligencia = "indice_inteligencia"
        val fuerza = "fuerza"


        val nombreFichero="solucion1.txt"

        val errorFactoria="Opción no válida"
        val mensajeFicheros = "Terminado leer fichero"
    }
}