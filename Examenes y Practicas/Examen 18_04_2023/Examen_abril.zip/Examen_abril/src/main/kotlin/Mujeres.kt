import java.io.Serializable

open class Mujeres:SeresVivos, Serializable {
    var indiceInteligencia: Int=0

    constructor(){}

    open fun realizarTarea(e:Tarea):Int{
        //0 no puede realizar la tarea, 1 puede realizar la tarea
        var i:Int =Constantes.noPuedoRealizarTarea
        if ((e.edadMinima <= this.edad) && (e.gradoResolucion <= this.indiceInteligencia)) i=Constantes.PuedoRealizarTarea
        return i
    }
}

