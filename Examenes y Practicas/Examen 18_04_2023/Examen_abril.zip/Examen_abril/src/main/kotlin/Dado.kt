import java.time.LocalDate
import kotlin.random.Random

class Dado {
    var caras:Int=0
    var historico= ArrayList<Int>()
    var tiradasIndividual = 0

    companion object{
        var tiradasTotales=0
    }

    constructor(n:Int){
        this.caras = n
    }
    fun tiradastotales():Int{
        return tiradasTotales
    }

    fun tirada():Int{
        tiradasTotales ++
        tiradasIndividual ++
        var n = Random.nextInt(1,caras+1)
        historico.add(n)
        return (n)
    }

    fun tirarRonda(n:Int): List<Int> {
        val resultados = ArrayList<Int>()
        for (i in 1..n) {
            resultados.add(tirada())
        }
        return resultados
    }

    fun estadisticas(){
        var numeros = Array<Int>(caras) { 0 }
        for (i in historico){
            numeros[i-1]= numeros[i-1]+1
        }
        var n = 0
        while (n<numeros.size){
            println("La cara ${n+1} estadistica ${String.format("%.2f",((numeros[n].toDouble()/historico.size.toDouble())*100))}")
            n++
        }
    }
}
fun main(args: Array<String>) {
    var dado1 = Dado(6)
    var dado2 = Dado(5)
    var n=1
    do{
        println(dado1.tirada())
        println(dado2.tirada())
        if ((n%3)==0){
            println(dado1.tirarRonda(n))
            println(dado2.tirarRonda(n))
        }
        n++
    }while (n<10)
    dado1.estadisticas()
    dado2.estadisticas()
    println(dado2.tiradastotales())
    println(dado1.tiradastotales())
}