import java.io.*

class Fichero {
    companion object {
        fun insertar(n: String, a: ArrayList<Guerreras>) {
            var os: ObjectOutputStream? = null
            try {
                var fs = FileOutputStream(n);//Creamos el archivo
                os = ObjectOutputStream(fs);//Esta clase tiene el método writeObject() que necesitamos
                for (i in a) {
                    os.writeObject(i);//El método writeObject() serializa el objeto y lo escribe en el archivo
                }
            } catch (e: FileNotFoundException) {
                e.printStackTrace();
            } catch (e: IOException) {
                e.printStackTrace();
            } finally {
                os?.close();//Hay que cerrar siempre el archivo
            }
        }
        fun leer(n: String) {
            var fis:FileInputStream
            var ois:ObjectInputStream? = null
            try {
                fis = FileInputStream(n)
                ois = ObjectInputStream(fis)
                while (true) {
                    var a1 = ois.readObject()
                    println(a1.toString())
                }

            } catch (e: FileNotFoundException) {
                e.printStackTrace()
            } catch (e:EOFException) {
                println(Constantes.mensajeFicheros)
                // Se captura la excepción EOFException al llegar al final del archivo
            }catch (e: IOException) {
                e.printStackTrace()
            } catch (e: ClassNotFoundException) {
                e.printStackTrace()
            }  finally {
                ois?.close();
            }
        }
    }
}