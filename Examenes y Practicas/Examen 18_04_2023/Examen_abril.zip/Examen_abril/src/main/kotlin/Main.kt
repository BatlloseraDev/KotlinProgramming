fun main(args: Array<String>) {
    var ganadores = ArrayList<Guerreras>()
    var a=Dado(6)
    var vueltas = a.tirada()
    var cantidad = a.tirada()
    for (i in 1..vueltas){
        var t = Tablero(cantidad)
        t.jugar(ganadores)
    }
    Fichero.insertar(Constantes.nombreFichero, ganadores)
    Fichero.leer(Constantes.nombreFichero)
}