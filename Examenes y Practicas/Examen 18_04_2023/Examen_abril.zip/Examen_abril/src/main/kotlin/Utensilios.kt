class Utensilios {
    var tipo:String = "Hacha"
}