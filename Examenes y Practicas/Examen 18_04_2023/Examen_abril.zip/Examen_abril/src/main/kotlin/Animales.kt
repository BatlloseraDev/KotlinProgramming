class Animales:SeresVivos {
    //0 libre, 1 no libre
    var estado:Int =0
    var fuerza:Int =0

    constructor(){}


}