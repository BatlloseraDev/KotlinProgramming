class Tablero {
    var equipo1 = ArrayList<Guerreras>()
    var equipo2 = ArrayList<Guerreras>()
    var retos = ArrayList<Tarea>()
    //var ganadores = ArrayList<Guerreras>()


    constructor(n:Int){
        crearEquipos(n)
        crearTareas(2*n)
    }

    fun crearEquipos(n:Int){
        //nos aseguramos que las listas esten vacias
        //if (equipo1.size>0) equipo1.clear()
        //if (equipo1.size>0) equipo1.clear()

        //creamos los nuevos equipos realizando una sola conexion
        var c=GuerrerasDAOImpl()
        var todos = c.xGuerreras(n)
        var x=0
        for (i in todos){
            if (x<2){
                equipo1.add(i)
                x++
            }
            else{
                equipo2.add(i)
            }
        }
    }

    fun crearTareas(n:Int){
        for (i in 1..n) {
            retos.add(FactoriaTarea.devolverUnaTarea())
        }
    }

    fun jugar(a:ArrayList<Guerreras>){
        /** otras formas de recorrer un List no vistas en clase utilizando la clase iterator
        val iterator1 = equipo1.iterator()
        val iterator2 = equipo2.iterator()
        val iteratorR = retos.iterator()

        while (iterator1.hasNext() && iterator2.hasNext() && iteratorR.hasNext()) {
        val i1 = iterator1.next()
        val i2 = iterator2.next()
        val r = iteratorR.next()
        }*/

        var index = 0
        while (index < equipo1.size && index < equipo2.size && index < retos.size) {
            val i1 = equipo1[index]
            val i2 = equipo2[index]
            val r = retos[index]

            if (i1.realizarTarea(r) == Constantes.PuedoRealizarTarea){
                //Lo guardamos
                a.add(i1)

            }
            if (i2.realizarTarea(r) == Constantes.PuedoRealizarTarea){
                //Lo guardamos
                a.add(i2)
            }
            index++
        }
    }
}