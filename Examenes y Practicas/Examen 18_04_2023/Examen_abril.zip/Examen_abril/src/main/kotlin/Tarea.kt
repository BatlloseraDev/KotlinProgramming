class Tarea {
    // 0 Fuerza, 1 otra cosa
    var tipo: Int = 0
    var gradoResolucion: Int  = 0
    var edadMinima: Int  = 0
    var cantidadFuerza = 0


    constructor(){}

    constructor(t:Int, g:Int, e :Int){
        tipo= t
        gradoResolucion = g
        edadMinima = e
    }

    constructor(t:Int, g:Int, e :Int, cf:Int){
        tipo= t
        gradoResolucion = g
        edadMinima = e
        cantidadFuerza=cf
    }

    override fun toString(): String {
        return "Tarea(tipo=$tipo, gradoResolucion=$gradoResolucion, edadMinima=$edadMinima, cantidadFuerza=$cantidadFuerza)"
    }

}