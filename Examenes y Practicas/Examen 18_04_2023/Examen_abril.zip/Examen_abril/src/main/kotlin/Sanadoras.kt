class Sanadoras:Mujeres {

    constructor()

    fun sanar(a:SeresVivos){
        a.esperanzaVida ++
    }

    override fun realizarTarea(e:Tarea):Int{
        //0 no puede realizar la tarea, 1 puede realizar la tarea
        var i:Int =Constantes.noPuedoRealizarTarea
        if (e.tipo != Constantes.Fuerza){
            if ((e.edadMinima <= this.edad) && (e.gradoResolucion <= this.indiceInteligencia)) i=Constantes.PuedoRealizarTarea
        }
        return i
    }
}