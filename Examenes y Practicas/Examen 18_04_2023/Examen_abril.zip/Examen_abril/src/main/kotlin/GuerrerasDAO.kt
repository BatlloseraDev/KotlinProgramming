interface GuerrerasDAO {
    fun xGuerreras(numero:Int): List<Guerreras>
}