import java.io.Serializable

open class SeresVivos: Serializable {
    var esperanzaVida:Int=0
    var edad:Int=0
    var nombre:String =""

    constructor(){}
    constructor(es:Int,n:String,e:Int ){
        this.esperanzaVida = es
        nombre = n
        edad = e
    }

    fun estoyVivo():Int{
        // 0 es joven, 1 mayor, 2 muerto
        var i:Int = Constantes.Joven
        if ((edad + 5) >=esperanzaVida) i  = Constantes.Mayor
        if (edad>= esperanzaVida ) i = Constantes.Muerto
        return i
    }

    override fun toString(): String {
        return "SeresVivos(esperanzaVida=$esperanzaVida, edad=$edad, nombre='$nombre')"
    }


}