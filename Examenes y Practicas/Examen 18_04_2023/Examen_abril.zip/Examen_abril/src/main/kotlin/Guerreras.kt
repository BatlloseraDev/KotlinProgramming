import java.io.Serializable

class Guerreras: Mujeres, Serializable {
    var fuerza: Int = 0
    var utensilios = ArrayList<Utensilios>()
    var animales = ArrayList<Animales>()

    constructor(esperanza:Int, edad:Int, nombre:String,inteligenia:Int,fuerza:Int){
        this.esperanzaVida = esperanza
        this.edad=edad
        this.nombre = nombre
        this.indiceInteligencia = inteligenia
        this.fuerza = fuerza
    }

    override fun realizarTarea(e:Tarea):Int{
        //0 no puede realizar la tarea, 1 puede realizar la tarea
        var i:Int =Constantes.noPuedoRealizarTarea
        if (e.tipo == Constantes.Fuerza){
            if ((e.edadMinima <= this.edad) &&
                (e.gradoResolucion <= this.indiceInteligencia) && e.cantidadFuerza<=fuerzaTotal()){
                i=Constantes.PuedoRealizarTarea
            }
        }
        return i
    }

    fun addAnimal(a:Animales){
        animales.add(a)
    }

    private fun fuerzaTotal():Int{
        var i=this.fuerza
        if (animales.size>0){
            for(a in animales){
                i = i + a.fuerza
            }
        }
        return i
    }

    override fun toString(): String {
        return "Guerreras(esperanzaVida=$esperanzaVida, edad=$edad, nombre='$nombre' fuerza=$fuerza)"
    }
    //fun returnAnimal():{}

}