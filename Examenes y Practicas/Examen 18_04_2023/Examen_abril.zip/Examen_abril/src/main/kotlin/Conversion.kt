import java.time.LocalDate
import kotlin.random.Random

class Conversion {
    companion object{
        fun textoFecha(s:String):LocalDate{
            //devuelve "0000/00/00 si el string no esta en formato ISO yyyy-MM-dd
           var f:LocalDate
            try{
                f = LocalDate.parse(s)
            }catch (e:Exception){
                f= LocalDate.of(0,1,12)
            }
            return f
        }

        fun fechaTexto(f:LocalDate):String{
            return f.toString()
        }

        fun textoEntero(s:String):Int{
            //devuelve 0 si no se puede convertir
            var n:Int
            try{
                n = s.toInt()
            }catch (e:Exception){
                n=0
            }
            return n
        }
        fun enteroTexto(n:Int):String {
            return n.toString()
        }

        fun esDivisible(x:Int,y:Int ):Boolean{
            return ((x % y) == 0)
        }
    }
}
fun main(args: Array<String>) {
    var s="10"
    var f = LocalDate.of(1973,9,3)
    var f1="1967-10-31"
    var f2="12-03-2023"

    println((Conversion.fechaTexto(f)))
    println(Conversion.textoFecha(f1))
    println(Conversion.textoFecha(f2))

    do{
        var n1= Random.nextInt(1,100)
        var n2= Random.nextInt(1,100)
        println("${n1} / ${n2}")
    }while (!(Conversion.esDivisible(n1,n2)))
    println()
}