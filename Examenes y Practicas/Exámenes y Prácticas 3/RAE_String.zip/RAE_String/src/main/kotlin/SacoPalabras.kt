class SacoPalabras {
    var cantidad=0
    var saco: Array<String>

    constructor(longitud:Int,saco:Array<String>){
        this.saco=saco
        this.cantidad = longitud
    }
    constructor(saco:Array<String>){
        this.saco = saco
        this.cantidad = saco.size
    }

    constructor(){
        var cantidad:Int?=0
        do {
            print("¿Tamaño del saco?: ")
            cantidad = readln().toIntOrNull()
            if ((cantidad == null) || (cantidad <= 0)){
                println("Introduce un valor numérico válido")
            }
        }while ((cantidad == null) || (cantidad <= 0))

        this.cantidad = cantidad
        saco = Array(this.cantidad){""}

        for (i in 0..<this.cantidad){
            println("Palabra ${i+1}")
            saco[i] = readln()
        }
    }

    fun comodin():String{
        return (saco.random())
    }
}