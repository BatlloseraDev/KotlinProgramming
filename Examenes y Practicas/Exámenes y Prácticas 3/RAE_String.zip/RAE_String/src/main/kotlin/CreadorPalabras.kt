class CreadorPalabras {

    var historial=Array(3){""}
    private var contadorPalabras: Int = 0

    fun crearPalabraLongitud(longitud: Int): String {
        val palabra = StringBuilder()
        repeat(longitud) {
            palabra.append(('a'..'z').random())
        }
        guardarPalabra(palabra.toString())
        return palabra.toString()
    }

    fun crearPalabraVocales(tamañoTotal: Int, numVocales: Int): String {
        val palabra = StringBuilder()
        if (numVocales <= tamañoTotal) {
            val numConsonantes = tamañoTotal - numVocales
            for (i in 1..numVocales) {
                palabra.append("aeiou".random())
            }
            for (i in 1..numConsonantes) {
                palabra.append(('a'..'z').random())
            }
        } else {
            for (i in 1..tamañoTotal) {
                palabra.append("aeiou".random())
            }
        }
        guardarPalabra(palabra.toString())
        return palabra.toString()
    }

    private fun guardarPalabra(palabra: String) {
        val indice = contadorPalabras % historial.size
        historial[indice] = palabra
        contadorPalabras++
    }

    fun control(caracter: Char, cantidadMaxima: Int):Boolean {
        var conteoCaracter = 0
        for (palabra in historial) {
                var indice = 0
                while (indice < palabra.length) {
                    if (palabra[indice] == caracter) {
                        conteoCaracter++
                    }
                    indice++
                }
        }
        var seguir = true
        if (conteoCaracter >= cantidadMaxima) {
           seguir = false
        }
        return seguir
    }

    override fun toString(): String {
        return "CreadorPalabras(historial=${historial.contentToString()})"
    }


}