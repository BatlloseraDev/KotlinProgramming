fun main(args: Array<String>) {

    var saco1 = SacoPalabras()
    println(saco1.comodin())
    var saco2= SacoPalabras(3,arrayOf("pepe", "juan", "lola"))
    println(saco2.comodin())
    val datosDeBBDD = arrayOf("pepe", "juan", "lola")
    var saco3= SacoPalabras(3,datosDeBBDD)
    println(saco3.comodin())


    val creador = CreadorPalabras()


    do{
        creador.crearPalabraLongitud(7)
        creador.crearPalabraVocales(10,4)
        println(creador.toString())

        println("*****************************")

        val palabra = saco2.comodin()
        val palabraDistorsionada = Distorsionador.distorsionar(palabra, 3)
        println("Resultado $palabraDistorsionada")
        val palabraEncriptada = Distorsionador.encriptar(palabra)
        println("Palabra encriptada: $palabraEncriptada")

    }while (creador.control('a',4))

    println("*****************************")
    println(creador.toString())



}