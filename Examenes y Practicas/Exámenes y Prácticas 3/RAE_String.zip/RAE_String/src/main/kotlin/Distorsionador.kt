class Distorsionador {
    companion object {
        private var contador= 0


        fun distorsionar(palabra: String, cantidad: Int): String {
            var palabraDistorsionada = palabra
            for (i in 1..cantidad) {
                val indiceAleatorio = (0 until palabraDistorsionada.length).random()
                val nuevoCaracter = ('a'..'z').random()
                palabraDistorsionada = palabraDistorsionada.replaceRange(indiceAleatorio, indiceAleatorio + 1, nuevoCaracter.toString())
            }
            contador++
            return palabra + "/" + palabraDistorsionada
        }

        fun encriptar(palabra: String): String {
            val numeroAleatorio = (1..palabra.length).random()

            var encriptada = palabra
            repeat(numeroAleatorio) {
                val indice1 = (0 until encriptada.length-3).random()
                var indice2 = (0 until encriptada.length-2).random()

                while (indice2 < indice1) {
                    indice2 = (0 until encriptada.length-2).random()
                }


                encriptada = encriptada.substring(0, indice1) +
                        encriptada[indice2] +
                        encriptada.substring(indice1, indice2) +
                        encriptada[indice1] +
                        encriptada.substring(indice2 + 1)
            }

            return encriptada
        }

    }

}