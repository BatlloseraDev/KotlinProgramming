fun main(args: Array<String>) {
    val MEDIA:Int = 25
    var cola= Array<Int>(30){0}
    var personasPorTurno: Int = 30
    var turno: Int = 1
    while(turno<=MEDIA){
        println(texto(4) + turno)
        rellenarCola(personasPorTurno,cola)
        imprimirCola(cola, texto(1))
        personasPorTurno = (limites(1)..limites(3)).random()
        println( texto(2)+ personasPorTurno)
        avanzarCola(personasPorTurno, cola)
        imprimirCola(cola, texto(3))
        turno ++
    }


}
fun limites(i:Int):Int{
    var n:Int=0
    when (i){
        1 -> n = 1
        3 -> n = 3
        9 -> n = 9
    }
    return n
}
fun texto(i:Int):String{
    var s:String=""
    when (i){
        1 -> s = "Cola esperando turno"
        2 -> s="   Personas atendidas en este turno: "
        3 -> s="Cola con los huecos generados"
        4 -> s="Turno "
        5 -> s="["
        6 -> s="]"
        7 -> s = "     "
    }
    return s
}
fun avanzarCola(cantidad:Int, v: Array<Int>){
    var i:Int = cantidad
    while (i<v.size){
        v[i-cantidad]= v[i]
        i++;
    }
    i=v.size - cantidad
    while (i<v.size){
        v[i]= 0
        i++;
    }
}
fun rellenarCola(cantidad: Int,v:Array<Int>){
    // cantidad es el numero de elementos a rellenar, se restaran a la longitud total
    //y desde esa posición se rellenara
    var i:Int = v.size - cantidad
    while (i<v.size){
        v[i]= (limites(1)..limites(9)).random()
        i++;
    }
}
fun imprimirCola(v:Array<Int>, s:String){
    println("   ${s}")
    print(texto(7))
    for (i in v.indices){
        print(texto(5) +v[i] + texto(6))
    }
    println()
}