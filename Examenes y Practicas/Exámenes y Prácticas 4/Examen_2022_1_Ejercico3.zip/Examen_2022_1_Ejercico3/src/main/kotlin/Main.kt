fun main(args: Array<String>) {
    val N = 9
    var zona:Int
    var energiaAtaque:Int
    var campamento= Array<Int>(N){0}
    for (i in campamento.indices){
        campamento[i]= (0..100).random()
    }
    zona = alerta()
    while (zona != -1){
        println("Zona Atacada: " + zona)
        println("Energia Zona Atacada: " + nivelZona(campamento,zona))

        if (nivelZona(campamento,zona)>50){
            println("Atacando alcampamento...")
            if (zona==8){
                energiaAtaque  =50
            }else {
                energiaAtaque = nivelZona(campamento, (zona + 1))
                if (energiaAtaque % 2 == 0) {
                    energiaAtaque = (energiaAtaque / 2)
                } else {
                    energiaAtaque = energiaAtaque - 7
                }
            }
            println("Energia de ataque: " + energiaAtaque)
            println("=====================")
            imprimirCampamento(campamento)
            ataqueCampamento(campamento,energiaAtaque)
            imprimirCampamento(campamento)

        }
        zona = alerta()
    }
    println("FIN")
}
fun alerta():Int{
    return (-1..8).random()
}
fun ataqueCampamento (v:Array<Int>, c:Int){
    for (i in v.indices){
        if (v[i]!= 0) {
            v[i] = v[i] - c
        }
    }
}
fun nivelZona(v:Array<Int>, z:Int):Int{
    return v[z]
}

fun aumentarEnergia(z:Int,v:Array<Int>, c:Int){
    v[z] = v[z] + c
}

fun imprimirCampamento(v:Array<Int>){

    for (i in v.indices){
        print("[" +v[i]+ "]")
    }
    println("")

}