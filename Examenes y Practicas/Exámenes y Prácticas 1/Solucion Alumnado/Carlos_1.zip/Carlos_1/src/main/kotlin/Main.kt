//Carlos Antonio Canal Da Silva
fun main() {
    var personas : Int?
    do {
        println("¿Cuantas personas van a votar? [El valor debe ser mayor o igual a 2]")
        personas = readln().toIntOrNull()
    }while (personas == null || personas < 2)

    var cantidadMinima : Int?
    do {
        println("¿Cuantos votos debe tener una opcion para considerarse valida? [El valor debe ser entre 2 y $personas]")
        cantidadMinima = readln().toIntOrNull()
    }while (cantidadMinima == null || cantidadMinima !in (2..personas))

    do {
        var votosLunes = 0
        var votosMiercoles = 0

        var personaActual = 1
        while (personaActual <= personas) {
            println("\n-------------------------------")
            println("Persona $personaActual, seleccione el horario que le viene mejor:")
            println("1) Lunes 10:00")
            println("2) Miercoles 11:30")
            println("3) Ambas opciones")
            println("4) Ninguna de las opciones")
            when (readln().toIntOrNull()) {
                1 -> {
                    println("Persona $personaActual ha seleccionado Lunes 10:00")
                    votosLunes++
                    personaActual++
                }
                2 -> {
                    println("Persona $personaActual ha seleccionado Miercoles 11:30")
                    votosMiercoles++
                    personaActual++
                }
                3 -> {
                    println("Persona $personaActual ha seleccionado ambas")
                    votosLunes++
                    votosMiercoles++
                    personaActual++
                }
                4 -> {
                    println("Persona $personaActual no ha seleccionado ninguna")
                    personaActual++
                }
                null -> {
                    println("DEBES ESCRIBIR UN DIGITO")
                }
                else -> {
                    println("OPCION INCORRECTA")
                }
            }
            println("-------------------------------")
        }

        println("\n===============================")
        println("Recuento de votos:")
        println("Lunes 10:00 : $votosLunes")
        println("Miercoles 11:30 : $votosMiercoles")

        var noHayGanador = true
        if (votosLunes == votosMiercoles) {
            println("Ha habido un empate entre ambas opciones")
        }else if (votosLunes > votosMiercoles) {
            if (votosLunes < cantidadMinima) {
                println("La opcion 1 (Lunes 10:00) ha sido la mas votada, pero no supera el minimo de votos ($cantidadMinima).")
            }else {
                println("La opcion 1 (Lunes 10:00) ha sido elegida.")
                noHayGanador = false
            }
        }else {
            if (votosMiercoles < cantidadMinima) {
                println("La opcion 2 (Miercoles 11:30) ha sido la mas votada, pero no supera el minimo de votos ($cantidadMinima).")
            }else {
                println("La opcion 2 (Miercoles 11:30) ha sido elegida.")
                noHayGanador = false
            }
        }

        if (noHayGanador) println("No hay resultado definitivo, por lo que se repetira la votacion.")
        println("===============================")
    }while (noHayGanador)
}