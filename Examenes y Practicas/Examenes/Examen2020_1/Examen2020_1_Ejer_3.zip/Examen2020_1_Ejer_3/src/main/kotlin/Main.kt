fun main(args: Array<String>) {
   var feliz = Array<Int>(1){0}
    feliz[0]= madrugar()
    var tiempo: Int = 0
    while(tiempo<22){
        if (chequeoFelicidad(feliz[0])){
            print("Hora:${tiempo} Gargando felicidad ${feliz[0]}")
            while (feliz[0]<(20+tiempo)){
                felicidad(feliz)
                print("..${feliz[0]}")
            }
            println()
        }
        if (tiempo>=8 && tiempo<=14){
            println("Hora ${tiempo}")
            aburrimientoExtremo()
            println()
        }
        tiempo++
    }
    tiempo = 0
    while ((tiempo<3600) && (tenerSuenio(tiempo)!=25)){
        tiempo++
        contarOvejas()
    }
    println("DULCES SUEÑOS")
}

fun aburrimientoExtremo(){
    var x:Int
    var y:Int
    do{
        x=(1..9).random()
        y=(2..8).random()
        if (x+y ==12) {
            print("(${x},${y})")
        }

    }while (!((x==y) && (x+y==12)))
}

fun madrugar():Int{
    return (0..100).random()
}
fun felicidad(v:Array<Int>){
    v[0]=v[0]+1
}
fun chequeoFelicidad(n:Int):Boolean{
    var tipo: Boolean = false
    if (n<=20) tipo=true
    return tipo
}

fun tenerSuenio(s:Int):Int{
    //una formula matemática inventada, pues no sabemos bien el funcionamiento para devolver 25
    //yo voy a supones que el segundo que entra lo multiplica por dos y le suma 1
    return ((s*2)+1)
}

fun contarOvejas(){
    print(".")
}