fun main(args: Array<String>) {
    val N: Int = 5
    var tablero = Array(N){Array<Int>(N){-1}}
    var tirada= Array<Int>(2){0}
    var puntosHumano:Int = 0
    var puntosPC:Int  = 0
    while(hayCasillas(tablero)) {
        println("========================================")
        println("PC ")
        tiradaPc(tablero,tirada)
        println("Tirada: "+ (tirada[0] +1 )+ " " + (tirada[1]+1))
        puntosPC = puntosPC + puntosTurno(tablero,tirada)
        imprimirTablero(tablero)


        //tiradaHumano(tablero,tirada)
        if (hayCasillas(tablero)) {
            println("========================================")
            println("Humano ")
            tiradaPc(tablero, tirada)
            println("Tirada: " + (tirada[0] +1 )+ " " + (tirada[1]+1))
            puntosHumano = puntosHumano + puntosTurno(tablero, tirada)
            imprimirTablero(tablero)
        }
    }
    println("Puntos Pc : " + puntosPC)
    println("Puntos Humano : " + puntosHumano)
    //tirada[0]=2
    //tirada[1]=2
    //puntosPC = puntosPC + puntosTurno(tablero,tirada)
}
fun puntosTurno(m:Array<Array<Int>>,v:Array<Int>): Int{
    var puntos: Int =0
    var f:Int = v[0]
    var c:Int = v[1]
    var f_aux:Int
    var c_aux: Int
    var f_aux2:Int
    var c_aux2: Int
    var i:Int = -1
    var j:Int = -1
    // println("--------------")
    while (i<2){
        j=-1
        //j=i
        while (j<2){

            if (!(i==0 && j==0) && (Math.abs(i)+ Math.abs(j) == 1)) {
                f_aux = f+i
                c_aux = c + j
                f_aux2 = f-i
                c_aux2 = c - j
                //println(""+f_aux + " "+c_aux +"/"+ f_aux2 +" "+c_aux2 )
                if ((f_aux >= 0 && f_aux<m.size && c_aux>=0 && c_aux<m.size)&&(f_aux2 >= 0 && f_aux2<m.size && c_aux2>=0 && c_aux2<m.size)) {
                    if (m[f][c]==0 && m[f_aux][c_aux]== 1 && m[f_aux2][c_aux2]== 1) {
                        //print("[" + m[f_aux][c_aux] + "]")
                        //println("OSO")
                        puntos = puntos + 1
                    }
                }

            }
            j++
        }
        i++
    }
    println("Has puntuados en la tirada: " + (puntos/2) + " asa" )
    return (puntos/2)
}

fun tiradaHumano(m:Array<Array<Int>>,v:Array<Int>){
    var tiradaNoValida = true
    var letra: String=""
    var x:Int=0
    var y:Int =0
    while (tiradaNoValida) {
        do {
            println("Dame la Fila (1-5)")
            x = (readln().toInt() - 1)
        } while (x < 0 || x >= 5)
        do {
            println("Dame la Columna (1-5)")
            y = (readln().toInt() - 1)
        } while (y < 0 || y >= 5)
        if (m[x][y] == -1){
            tiradaNoValida = false
        }else{
            println("Casilla ocupada")
        }
    }
    do{
        println("Dame la letra")
        letra = readln().uppercase()

    }while (!(letra == "A" || letra == "S"))

    if (letra == "A") m[x][y] = 1
    if (letra == "S") m[x][y] = 0
    v[0]=x
    v[1]=y

}
fun hayCasillas(m:Array<Array<Int>>):Boolean{
    var lleno: Boolean = false
    var i:Int =0
    var j: Int =0
    while ((i<m.size) && !lleno){
        j=0
        while ((j<m.size) && !lleno){
            if (m[i][j] == -1) lleno = true
            j ++
        }
        i++
    }
    return lleno
}
fun tiradaPc(m:Array<Array<Int>>,v:Array<Int>){
    var tiradaNoValida = true
    var x:Int = 0
    var y:Int = 0
    while (tiradaNoValida){
        x = (0..4).random()
        y = (0..4).random()
        if (m[x][y] == -1){
            tiradaNoValida = false
        }
    }
    m[x][y] = (0..1).random()
    v[0]=x
    v[1]=y
}

fun imprimirTablero(m:Array<Array<Int>>){

    for (i in m.indices){
        for (j in m[i].indices){
            if (m[i][j]==0){
                print("[S]")
            }
            if (m[i][j]==1){
                print("[A]")
            }
            if (m[i][j]==-1){
                print("[ ]")
            }
        }
        println()

    }
}

