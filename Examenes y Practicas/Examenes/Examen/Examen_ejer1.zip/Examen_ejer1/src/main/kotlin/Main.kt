fun main(args: Array<String>) {

    var v=Array<Int>(100){0}
    do{
        cargarNumero(v)
    }while(seguirRellenando(v))
    imprimirSolucion(v)
}
fun cargarNumero(v:Array<Int>){
    val MENOR:Int = 0
    val MAYOR:Int = 99
    var aleatorio: Int = (MENOR..MAYOR).random()
    v[aleatorio] = v[aleatorio] + 1
}
fun seguirRellenando(v:Array<Int>):Boolean{
    //sumar todos los numeros y si es cero.
    //revisar el array
    var seguir : Boolean = false
    for(i in v.indices){  // while (i<v.size) && (!seguir) esta opcion es más eficiente
        //if ((v[i])==0){seguir=true}
        if ((v[i])==0){seguir=true}
    }
    return seguir
}
fun imprimirSolucion(v:Array<Int>){
    for(i in v.indices){
        print("[${v[i]}]")
    }
    println()
}