fun main(args: Array<String>) {
    var bombo=Array<Int>(21){0} //bombo de 21 la posicion cero no se utiliza no debo imprimirla
    var bola:Int
    //Cartones:
    //en la fila 1 estaran los numeros elegidos
    //en la fila 2 estaran si el numero ya a salido  o no
    // utilizaremos el numero 1 para señalar que un numero esta acertado
    var cartonPC= Array(2){Array<Int>(5){0}}
    var cartonHumano= Array(2){Array<Int>(5){0}}
    rellenarCartonHumano(cartonHumano)
    rellenarCartonPC(cartonPC)
    imprimirCarton(cartonHumano, "Humano")
    imprimirCarton(cartonPC, "PC")
    do{
        bola = sacarBola(bombo)
        println("Tirada ------------------------->BOLA: " + bola )

        comprobar(bola,cartonHumano)
        comprobar(bola,cartonPC)
        imprimirBombo(bombo)
        imprimirCarton(cartonHumano, "Humano")
        imprimirCarton(cartonPC, "PC")
    }while(seguirJugando(cartonHumano,cartonPC))
    println("FIN")

}
fun comprobar(n:Int, m:Array<Array<Int>>){
    for(i in m[0].indices){
        if (m[0][i]== n){
            m[1][i]=1 //el número esta acertado
        }
    }
}
fun sacarBola(v:Array<Int>):Int{
    var bola: Int
    var repetido:Boolean
    do{
        bola = (1..20).random()
        repetido=false
        for(i in v.indices){
            if (v[bola]== 1){
                repetido = true
            }
        }
        if (!repetido){
            v[bola] = 1
        }

    }while(repetido)
    return bola
}
fun rellenarCartonHumano(v:Array<Array<Int>>){
    var j:Int =0
    var n:Int
    var repetido:Boolean
    do{
        do{
            println("Dame el número del cartón")
            n = readln().toInt()
        }while((n<=0)||(n>20))
        repetido=false
        for(i in v[0].indices){
            if (v[0][i]== n){
                repetido = true
            }
        }
        if (!repetido){
            v[0][j] = n
            j++
        }else{
            println("Repetido")
        }

    }while(j<v[0].size)
}
fun rellenarCartonPC(v:Array<Array<Int>>){
    var j:Int =0
    var n:Int
    var repetido:Boolean
    do{
        n = (1..20).random()
        repetido=false
        for(i in v[0].indices){
            if (v[0][i]== n){
                repetido = true
            }
        }
        if (!repetido){
            v[0][j] = n
            j++
        }else{
            println("Repetido")
        }

    }while(j<v[0].size)
}
fun inicializarCarton(a:Array<Array<Int>>){
    for (i in a.indices){
        for (j in a[i].indices){
            a[i][j]=0
        }
    }
}
fun imprimirCarton(a:Array<Array<Int>>,s:String){
    println(s)
    for (i in a.indices){
        for (j in a[i].indices){
            print("[" + a[i][j] + "]")
        }
        println()
    }
}
fun imprimirBombo(a:Array<Int>){
    println("PANEL DE SALIDA DE BOLAS")
    for (i in 1..(a.size-1)){
       if (a[i] == 1){
           print("[" + i + "]")
       }
       else{
           print("[" + a[i] + "]")
       }
    }
    println()
}
fun inicializarBombo(a:Array<Int>){
    var i:Int =1
    for(i in a.indices){
        a[i]=0
    }
}
fun seguirJugando(hu:Array<Array<Int>>,pc:Array<Array<Int>>):Boolean{
    var seguir: Boolean = true
    var pcContar:Int =0
    var huContar:Int=0
    for(i in hu[0].indices){
        if (hu[1][i]== 1){
            huContar ++
        }
        if (pc[1][i]== 1){
            pcContar ++
        }
    }
    if (huContar==5 || pcContar == 5) seguir=false
    return seguir
}